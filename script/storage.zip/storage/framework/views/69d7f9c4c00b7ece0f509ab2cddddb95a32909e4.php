<?php if($childrens): ?>
<li class="nav-item">
	<?php if(isset($childrens->children)): ?> 
	<a class="page-scroll dd-menu collapsed" <?php if(url()->current() == url($row->href)): ?> class="active" <?php endif; ?> href="<?php echo e(url($childrens->href)); ?>" <?php if(!empty($childrens->target)): ?> target=<?php echo e($childrens->target); ?> <?php endif; ?>

		data-bs-toggle="collapse" data-bs-target="#submenu-1-4" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<?php echo e($childrens->text); ?></b>
		
	</a>
	
	<ul class="sub-menu collapse" id="submenu-1-4">
		<?php $__currentLoopData = $childrens->children ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo $__env->make('theme.resto.components.menu.child', ['childrens' => $row], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</ul>
	<?php else: ?>
	<a href="<?php echo e(url($childrens->href)); ?>"><?php echo e($childrens->text); ?></a>
	<?php endif; ?>
</li>
<?php endif; ?>


<?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/resto/components/menu/child.blade.php ENDPATH**/ ?>