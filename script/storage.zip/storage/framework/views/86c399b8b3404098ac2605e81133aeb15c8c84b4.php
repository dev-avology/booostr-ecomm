

<?php $__env->startSection('content'); ?>
<section class="section">
    
    <div class="section-header">
        <a href="<?php echo e(url('seller/attribute')); ?>" class="btn btn-primary mr-2">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h1><?php echo e(__('Edit Attribute')); ?></h1>
    </div>
    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.storenotification','data' => []]); ?>
<?php $component->withName('storenotification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


    <div class="row">
        <div class="col-lg-12">
         <form class="ajaxform" method="post" action="<?php echo e(route('seller.attribute.update',$info->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                
                <div class="col-lg-5">
                    <strong><?php echo e(__('Attribute')); ?></strong>
                    <p><?php echo e(__('Add your attribute name and necessary information from here.')); ?></p>
                </div>
                

                
                <div class="col-lg-7">
                    <div class="card">
                        <div class="card-body">
                            <div class="from-group row mb-2">
                                <label for="" class="col-lg-12"><?php echo e(__('Name :')); ?> </label>
                                <div class="col-lg-12">
                                    <input type="text" name="parent_name" class="form-control" required="" placeholder="Parent Attribute" value="<?php echo e($info->name); ?>">
                                </div>
                            </div>
                            <div class="from-group row mb-2">
                                <label for="" class="col-lg-12"><?php echo e(__('Type :')); ?> </label>
                                <div class="col-lg-12">
                                    <select class="form-control selectric" id="select_type" name="select_type">
                                      
                                        
                                        <option value="radio"><?php echo e(__('Radio Button')); ?></option>
                                        
                                        <option value="color_single"><?php echo e(__('Color Selector')); ?></option>
                                        
                                    </select>
                                </div>
                            </div>
                            
                         <input type="hidden" name="featured" value="0">

                     </div>
                     <div class="card-footer">
                        <button class="btn btn-primary basicbtn"><?php echo e(__('Save')); ?></button>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="row">
            
            <div class="col-lg-5">
                <strong><?php echo e(__('Attribute Values')); ?></strong>
                <p><?php echo e(__('Add your attribute value and necessary information from here')); ?></p>
            </div>
            

            
            <div class="col-lg-7">
                <div class="card">
                    <div class="card-body child_row">
                        <?php $__currentLoopData = $info->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="from-group row mb-2 attribute-value childs child<?php echo e($key); ?>">
                            <div class="col-lg-10">
                                <label for="" class="d-block"><?php echo e(__('Name:')); ?> </label>
                                <input type="text" required name="oldchild[<?php echo e($row->id); ?>]" class="form-control" placeholder="Enter Child Attribute Name" value="<?php echo e($row->name); ?>">
                            </div>
                            <div class="col-lg-2">
                                <label for="" class="text-danger"><?php echo e(__('Remove')); ?></label>
                                <button type="button" data-id="<?php echo e($key); ?>"  class="btn btn-danger trash"><i class="fa fa-trash"></i></button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="card-footer">
                        <div class="from-group row mb-2 attribute-value">
                            <div class="col-lg-12">
                                <button type="button" class="btn btn-primary add_more"><i class="fa fa-plus"></i> <?php echo e(__('Add Child Attribute')); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </form>
</div>
</div>
</section>
<input type="hidden" id="typ" value="<?php echo e($info->slug); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
"use strict";

var total=<?php echo e($info->categories->count()); ?>;
</script>
<script src="<?php echo e(asset('admin/js/attribute-edit.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/attribute/edit.blade.php ENDPATH**/ ?>