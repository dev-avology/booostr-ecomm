<!DOCTYPE html>
  <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      
      <?php echo SEOMeta::generate(); ?>

      <?php echo OpenGraph::generate(); ?>

      <?php echo Twitter::generate(); ?>

      <?php echo JsonLd::generate(); ?>

      <?php echo JsonLdMulti::generate(); ?>

      <?php echo SEO::generate(true); ?>


      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('uploads/'.tenant('uid').'/favicon.ico')); ?>">
      <!-- Web Font -->
      <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/bootstrap.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/icofont.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/nice-select.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/animate.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/tiny-slider.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/glightbox.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/perfect-scrollbar.css')); ?>">
      <!-- Theme Styles -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/reset.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/style.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/resto/css/responsive.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/helper.css')); ?>">
      <?php echo $__env->yieldPushContent('css'); ?>
      <?php echo e(load_header()); ?>

   </head>
   <body>
     <?php
     $autoload_data=getautoloadquery();
     $average_times=optionfromcache('average_times');
    
     $cart_count=Cart::instance('default')->count();
     $wishlist_count=Cart::instance('wishlist')->count();
     ?>
      <!--[if lte IE 9]>
      <p class="browserupgrade">
         You are using an <strong>outdated</strong> browser. Please
         <a href="https://browsehappy.com/">upgrade your browser</a> to improve
         your experience and security.
      </p>
     <![endif]-->
      <?php if(isset($autoload_data['site_settings'])): ?>
      <?php
      $site_settings=json_decode($autoload_data['site_settings']);
      $site_settings=$site_settings->meta ?? '';
      $preloader=$site_settings->preloader ?? 'yes';
      ?>

      <?php if($preloader == 'yes'): ?>
      <div class="preloader">
         <div class="preloader-inner">
            <div class="preloader-icon"><span></span><span></span></div>
         </div>
      </div>
      <?php endif; ?>

      <?php endif; ?>

     <?php echo $__env->make('theme.resto.layouts.header',['autoload_data'=>$autoload_data,'cart_count'=>$cart_count,'wishlist_count'=>$wishlist_count,'average_times'=>$average_times,'site_settings'=>$site_settings ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->yieldContent('content'); ?>
     <?php echo $__env->make('theme.resto.layouts.footer',['site_settings'=>$site_settings ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php if(isset($autoload_data['whatsapp_settings'])): ?>
     <?php
     $whatsapp= json_decode($autoload_data['whatsapp_settings'])
     ?>
     <?php if($whatsapp->whatsapp_status == 'on'): ?>
       <?php echo $__env->make('components.whatsapp',['whatsapp'=>$whatsapp], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php endif; ?>
     <?php endif; ?>
<!--  scroll-top -->
<a href="#" class="scroll-top btn-hover"><i class="icofont-long-arrow-up"></i></a>
<input type="hidden" id="callback_url" value="<?php echo e(url('/databack')); ?>">  
<input type="hidden" id="cart_link" value="<?php echo e(route('add.tocart')); ?>" />
<input type="hidden" id="base_url" value="<?php echo e(url('/')); ?>" />
<input type="hidden" id="click_sound" value="<?php echo e(asset('uploads/click.wav')); ?>">
<input type="hidden" id="cart_sound" value="<?php echo e(asset('uploads/cart.wav')); ?>">
<input type="hidden" id="cart_increment" value="<?php echo e(url('/cart-qty')); ?>">
<input type="hidden" id="pos_product_varidation" value="<?php echo e(url('/product-varidation')); ?>">
<input type="hidden" id="cart_content" value="<?php echo e(Cart::content()); ?>">
<input type="hidden" class="total_amount" value="<?php echo e(str_replace(',','',Cart::total())); ?>">
<input type="hidden" id="preloader" value="<?php echo e(asset('uploads/preload.webp')); ?>">
<input type="hidden" id="currency_settings" value="<?php echo e($autoload_data['currency_data'] ?? ''); ?>">
<!--  JS Files  -->
<script src="<?php echo e(asset('theme/resto/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/nice-select.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/tiny-slider.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('theme/helper.js?v=1.0')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/theme-helper.js')); ?>"></script>

<?php echo $__env->yieldPushContent('js'); ?>
<?php echo e(load_footer()); ?>

  </body>
</html><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/resto/layouts/app.blade.php ENDPATH**/ ?>