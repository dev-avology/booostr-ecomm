

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Tags','button_name'=> 'Create','button_link'=> url('seller/tag/create')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.storenotification','data' => []]); ?>
<?php $component->withName('storenotification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="Search"><?php echo e(__('Search')); ?></label>
                         <form method="get">
                            <div class="row">
                                <input name="src" type="text" value="<?php echo e($request->src ?? ''); ?>" class="form-control col-lg-4 ml-2" placeholder="search...">
                            </div>
                         </form>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover text-center table-borderless">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('Name')); ?></th>
                                    <!-- <th><?php echo e(__('Url')); ?></th> -->
                                    <th><?php echo e(__('Created At')); ?></th>
                                    <th><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($row->name); ?></td>
                                  <!-- <td><?php echo e(url('/tag',$row->slug)); ?></td> -->
                                  <td><?php echo e(date('d-m-Y', strtotime($row->created_at))); ?></td>
                                  <td class="">
                                    <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Action
                                    </button>
                                    <div class="dropdown-menu tags-dropdown" x-placement="bottom-start">
                                       
                                        <a class="dropdown-item has-icon text-warning" href="<?php echo e(route('seller.tag.edit', $row->id)); ?>"><i class="fa fa-edit"></i><?php echo e(__('Edit')); ?></a>
                                        <a class="dropdown-item has-icon delete-confirm text-danger" href="javascript:void(0)" data-id="<?php echo e($row->id); ?>"><i class="fa fa-trash"></i><?php echo e(__('Delete')); ?></a>
                                        <!-- Delete Form -->
                                         <form class="d-none" id="delete_form_<?php echo e($row->id); ?>" action="<?php echo e(route('seller.tag.destroy', $row->id)); ?>" method="POST">
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field('delete'); ?>
                                    </form>
                                    </div>
                                </td>
                            </tr>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                     <?php echo e($posts->links('vendor.pagination.bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/tag/index.blade.php ENDPATH**/ ?>