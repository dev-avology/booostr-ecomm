[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\wamp64\www\avology\script\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>