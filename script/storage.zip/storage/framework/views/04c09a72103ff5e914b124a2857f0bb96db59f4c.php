<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\avology\script\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>