<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Edit Product Price','prev'=> url('seller/product')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('product_content'); ?>
<div class="tab-pane fade show active" id="general_info" role="tabpanel" aria-labelledby="home-tab4">
   <form class="ajaxform_with_reload" action="<?php echo e(route('seller.product.update',$info->id)); ?>" method="post">
      <?php echo csrf_field(); ?>
      <?php echo method_field("PUT"); ?>
      <div class="from-group row mb-2">
        <label for="" class="col-lg-12"><?php echo e(__('Name :')); ?> </label>
        <div class="col-lg-12">
            <input type="text" readonly name="name" required="" class="form-control" placeholder="Enter Product Name" value="<?php echo e($info->title); ?>">
        </div>
      </div>
      <div class="from-group row mb-2">
         <label for="" class="col-lg-12"><?php echo e(__('Price Type')); ?> : </label>
         <div class="col-lg-12">
            <select name="product_type"  class="form-control product_type">
            <option value="0" <?php if($info->is_variation == 0): ?> selected <?php endif; ?>><?php echo e(__('Simple Product')); ?></option>
            <option value="1" <?php if($info->is_variation == 1): ?> selected <?php endif; ?>><?php echo e(__('Variation Product')); ?></option>
            </select>
         </div>
      </div>
      <input type="hidden" name="type" value="price">
      <div class="<?php echo e($info->is_variation == 1 ? 'none' : ''); ?> single_product_area accordion-body">
         <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Product Price')); ?> : </label>
            <div class="col-lg-12">
               <input type="text" step="any" class="form-control product_price_input" name="price" value="<?php if($info->price): ?><?php echo e($info?->price->price ? '$'.number_format($info?->price->price, 2) : ''); ?><?php endif; ?>" placeholder="$0.00">
            </div>
         </div>
         <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Quantity')); ?> : </label>
            <div class="col-lg-12">
               <input type="number" class="form-control stock-qty" name="qty" value="<?php echo e($info->price->qty ?? ''); ?>" placeholder="0">
            </div>
         </div>
         <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('SKU')); ?> : </label>
            <div class="col-lg-12">
               <input type="text" class="form-control" name="sku" value="<?php echo e($info->price->sku ?? ''); ?>">
            </div>
         </div>
         <?php if($selected_product_type == "Physical Product"): ?>
         <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Weight')); ?> : </label>
            <div class="col-lg-12">
               <input type="number" step="any" class="form-control" name="weight" value="<?php echo e($info->price->weight ?? ''); ?>" placeholder="0.00">
            </div>
         </div>
         <?php endif; ?>

         <?php
         $stock_manage=$info->price->stock_manage ?? '';
         $stock_status=$info->price->stock_status ?? '';
         ?>
         <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Manage Stock')); ?> : </label>
            <div class="col-lg-12">
               <select name="stock_manage" class="manage_stock form-control selectric">
               <option value="1" <?php if($stock_manage == 1): ?> selected="" <?php endif; ?>><?php echo e(__('Yes')); ?></option>
               <option value="0" <?php if($stock_manage == 0): ?> selected="" <?php endif; ?>><?php echo e(__('No')); ?></option>
               </select>
            </div>
         </div>
         <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Stock Status')); ?> : </label>
            <div class="col-lg-12">
               <select name="stock_status" class="form-control selectric">
               <option value="1" <?php if($stock_status == 1): ?> selected="" <?php endif; ?>><?php echo e(__('In Stock')); ?></option>
               <option value="0" <?php if($stock_status == 0): ?> selected="" <?php endif; ?>><?php echo e(__('Out Of Stock')); ?></option>
               </select>
            </div>
         </div>
      </div>

      <div class="from-group row mb-2">
         <label for="" class="col-lg-12"><?php echo e(__('Tax')); ?> : </label>
         <?php 
           $tax=$info->price->tax ?? 1;
         ?>
         <div class="col-lg-12">
            <select name="tax" class="form-control selectric">
               <option value="1" <?php if($tax == 1): ?> selected="" <?php endif; ?>><?php echo e(__('Enable')); ?></option>
               <option value="0" <?php if($tax == 0): ?> selected="" <?php endif; ?>><?php echo e(__('Disable')); ?></option>
            </select>
         </div>
      </div>
  

      <div class="variation_product_area <?php echo e($info->is_variation == 0 ? 'none' : ''); ?>">
         <div id="accordion">

            <?php 
            $usedarrtibuteOption = [];
            ?>

            <?php $__currentLoopData = $info->productoptionwithcategories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $selected_childs=[];
            $usedarrtibuteOption[$row->id] = $row->categorywithchild->name;

            foreach($row->priceswithvaritions->unique() ?? [] as $price_category){
                array_push($selected_childs, $price_category->id);
            }
            ?>
             <div class="accordion renderchild<?php echo e($key); ?>">
               <div class="accordion-header h-50" role="button" data-toggle="collapse" data-target="#panel-body-<?php echo e($key); ?>">
                  <div class="float-left">
                     <h6>
                        <span id="option_name4"><?php echo e($row->categorywithchild->name ?? ''); ?></span>
                        <?php if($row->is_required == 1): ?><span class="text-danger">*</span> <?php endif; ?>
                    </h6>
                  </div>
                  <div class="float-right">
                     <a class="btn btn-danger btn-sm text-white option_delete" data-id="<?php echo e($key); ?>" data-old_attr_id="<?php echo e($row->id); ?>"><i class="fa fa-trash"></i></a>
                  </div>
               </div>
               <div class="accordion-body collapse show" id="panel-body-<?php echo e($key); ?>" data-parent="#accordion">
                  <div class="row mb-2 " >
                     <div class="col-lg-6 from-group">
                        <label for="" ><?php echo e(__('Select Attribute :')); ?> </label>
                        <select required name="parentattribute[]"  class="form-control parentattribute selectric parentattribute<?php echo e($key); ?>">
                           <option value="<?php echo e($row->category_id); ?>"  class="parentAttr<?php echo e($row->id); ?>" data-parentname="<?php echo e($row->name); ?>" data-short="<?php echo e($key); ?>" data-childattributes="<?php echo e($row->categorywithchild->categories); ?>"><?php echo e($row->categorywithchild->name ?? ''); ?></option>
                        </select>
                     </div>
                     <div class="col-lg-6 from-group">
                        <label for="" ><?php echo e(__('Select Attribute Values :')); ?> </label>
                        <select required  class="form-control select2 childattribute childattribute<?php echo e($key); ?> multi-select" multiple="">
                            <?php $__currentLoopData = $row->categorywithchild->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                            <?php if(in_array($category->id, $selected_childs)): ?>
                            selected
                            <?php endif; ?>
                            value="<?php echo e($category->id); ?>"
                            data-parentid="<?php echo e($row->id); ?>"
                            data-parent="<?php echo e($row->categorywithchild->name ?? ''); ?>"
                            data-short="<?php echo e($key); ?>"
                            data-attrname="<?php echo e($category->name); ?>"
                            class='child_attr<?php echo e($category->id); ?>

                            childattr<?php echo e($key); ?>'
                            >
                            <?php echo e($category->name); ?>

                           </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                     </div>
                     
                  </div>
                  <hr>
                 
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <div class="accordion renderchildVaritions">
               <div class="accordion-header h-50" >
                  <div class="float-left">
                     <h6>
                      Variation Products
                    </h6>
                  </div>
                   <div class="float-right">
                     <button class="btn btn-secondary float-right add_more_attribute" type="button"><i class="fas fa-plus"></i> <?php echo e(__('Add More variation')); ?></button>
                  </div>
               </div>
               <div class="accordion-body collapse show" id="panel-body-Varitions" data-parent="#accordion">
                  <p id = "variation-delete-msg" style = "color:red;"></p>

                  <div id="children_attribute_render_area">
                     <?php 
                     $used_combination = [];
                     $allVariationNames = []; 
                     ?>
                     <?php $__currentLoopData = $info->prices ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priceswithcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                           $class = '';
                            foreach($priceswithcategory->varitions as $varition){
                               $class .= ' attr-'.$varition->name; 
                            }
    
                         ?> 

                      <div class="accordion<?php echo e($class); ?>" id="childcard<?php echo e($priceswithcategory->id); ?>">
                        <div class="accordion-header h-50" role="button" data-toggle="collapse" data-target="#panel-body-<?php echo e($priceswithcategory->id); ?>">
                           <div class="float-left">   
                                 <h4> 
                                       <?php 
                                       $usku = ''; 
                                       $variationNames = []; 
                                       ?>
                                       <?php $__currentLoopData = $priceswithcategory->varitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $varition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       <?php echo e($usedarrtibuteOption[$varition->pivot->productoption_id] ?? ''); ?> / <span class="text-danger">  <?php echo e($varition->name ?? ''); ?></span>
                                       <?php 
                                       $usku .= $varition->id; 
                                       $variationNames[] = $varition->name;
                                       $allVariationNames[] = $varition->name;
                                       ?>
                                       <input type="hidden" name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][varition][<?php echo e($varition->pivot->productoption_id); ?>]" value="<?php echo e($varition->id); ?>">
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $used_combination[] = trim($usku); ?>
      
                                 </h4>
                           </div>
                           <div class="float-right">
                              <a class="btn btn-danger btn-sm text-white varition_option_delete" data-id="<?php echo e($priceswithcategory->id); ?>" data-old_id="<?php echo e($priceswithcategory->id); ?>"><i class="fa fa-trash"></i></a>
                           </div>      
                        </div>

      
                        <div class="accordion-body collapse show" id="panel-body-<?php echo e($priceswithcategory->id); ?>" data-parent="#children_attribute_render_area">
                           <div class=" row">
                              <div class="from-group col-lg-6">
                                 <label for="" ><?php echo e(__('Price :')); ?> </label>
                                 <div >
                                    <input type="number" step="any" class="form-control" name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][price]" value="<?php echo e($priceswithcategory->price); ?>" />
                                 </div>
                              </div>
                              <div class="from-group col-lg-6  mb-2 ">
                                 <label for=""><?php echo e(__('Stock Quantity :')); ?> </label>
                                 <div >
                                    <input type="number" class="stock-qty form-control" <?php if($priceswithcategory->stock_manage == 0): ?> disabled <?php endif; ?>  name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][qty]" value="<?php echo e($priceswithcategory->qty); ?>"/>
                                 </div>
                              </div>
                              <div class="from-group col-lg-6 mb-2">
                                 <label for="" ><?php echo e(__('SKU :')); ?> </label>
                                 <div >
                                    <input type="text" class="form-control" name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][sku]" value="<?php echo e($priceswithcategory->sku); ?>"/>
                                 </div>
                              </div>
                              <div class="from-group col-lg-6  mb-2">
                                 <label for="" ><?php echo e(__('Weight :')); ?> </label>
                                 <div >
                                    <input type="number" step="any" class="form-control" name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][weight]" value="<?php echo e($priceswithcategory->weight); ?>"/>
                                 </div>
                              </div>
                              <div class="from-group col-lg-6  mb-2">
                                 <label for="" ><?php echo e(__('Manage Stock ?')); ?> </label>
                                 <div >
                                    <select class="form-control selectric manage_stock" name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][stock_manage]">
                                       <option value="1" <?php if($priceswithcategory->stock_manage == 1): ?> selected <?php endif; ?>><?php echo e(__('Yes')); ?></option>
                                       <option value="0" <?php if($priceswithcategory->stock_manage == 0): ?> selected <?php endif; ?>><?php echo e(__('No')); ?></option>
                                    </select>
                                 </div>
                              </div>
                              <div class="from-group col-lg-6  mb-2">
                                 <label for="" ><?php echo e(__('Stock Status:')); ?> </label>
                                 <div >
                                    <select class="form-control selectric" name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][stock_status]">
                                       <option value="1" <?php if($priceswithcategory->stock_status == 1): ?> selected <?php endif; ?>><?php echo e(__('In Stock')); ?></option>
                                       <option value="0" <?php if($priceswithcategory->stock_status == 0): ?> selected <?php endif; ?>><?php echo e(__('Out Of Stock')); ?></option>
                                    </select>
                                 </div>
                              </div>
      
                              <!--div class="from-group col-lg-6  mb-2">
                                 <label for="" ><?php echo e(__('Tax:')); ?> </label>
                                 <div >
                                    <select class="form-control selectric" name="childattribute[priceoption][<?php echo e($priceswithcategory->id); ?>][tax]">
                                       <option value="1" <?php if($priceswithcategory->tax == 1): ?> selected <?php endif; ?>><?php echo e(__('Enable')); ?></option>
                                       <option value="0" <?php if($priceswithcategory->tax == 0): ?> selected <?php endif; ?>><?php echo e(__('Disable')); ?></option>
                                    </select>
                                 </div>
                              </div-->
                           </div>
                        </div> 
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
                  </div>   


               </div>   

         </div>
         
      </div>    
      </div>

      <div class="from-group  mb-2">
         <button class="btn btn-primary basicbtn col-lg-2 float-left" type="submit"><i class="far fa-save"></i> <?php echo e(__('Update')); ?></button>
    
         <button class="btn btn-primary col-lg-3 ml-5 create_variation_product" style="display:none" type="button"><i class="fas fa-plus"></i> <?php echo e(__('Create variation products')); ?></button>

      </div>
   </form>
</div>
<input type="hidden" id="max_short" value="<?php echo e(count($info->productoptionwithcategories)); ?>">
<input type="hidden" id="parentattributes" value="<?php echo e($attributes); ?>" />
<input type="hidden" id="used_combination" value='<?php echo json_encode($used_combination,true); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/product-price.js?v=1')); ?>"></script>

<script>
  $(document).on('change', '.manage_stock', function() {
    if ($(this).val() == 0) {
        $(this).closest('.accordion-body').find('.stock-qty').prop('disabled', true);
    } else {
        $(this).closest('.accordion-body').find('.stock-qty').prop('disabled', false);
    }
  });

    $(".product_price_input").change(function() {
       // This function will be executed when the input value changes.
       var inputValue = $(this).val();
       inputValue = inputValue.match(/[0-9.]+/g);
       if(inputValue === null || inputValue === ''){
          return;
       }
       $(this).val("$" + parseFloat(inputValue).toFixed(2));
    });

    $('.varition_option_delete').click(function() {
      var id = $(this).data('id');
      var oldId = $(this).data('old_id');

      $.ajax({
        url: '/seller/product/remove-price/'+oldId, 
        method: 'GET',
        success: function(response) {
          console.log('GET request successful:', response);
          $('#variation-delete-msg').text('Variation product deleted successfully');
          removeAttrValue();
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.error('GET request failed:', textStatus, errorThrown);
        }
      });
   });

   $('.option_delete').click(function() {
      var id = $(this).data('old_attr_id');

      $.ajax({
        url: '/seller/product/remove-variation-attribute/'+id, 
        method: 'GET',
        success: function(response) {
          console.log('GET request successful:', response);
          $('#variation-delete-msg').text('Variation attribute deleted successfully');
        },
        error: function(jqXHR, textStatus, errorThrown) {
          console.error('GET request failed:', textStatus, errorThrown);
        }
      });
   });

   function removeAttrValue() {
    $(".parentattribute option:selected").each(function(index, row) {
      $(".childattribute" + $(row).data('short') + " option:selected").each(function(index, row1) {
         var attrVal = $(row1).data('attrname'); 
         var new_attr = '#children_attribute_render_area .attr-'+attrVal;
          if($(new_attr).length == 0 ){
             $(this).prop("selected", false)
             $(".childattribute" + $(row).data('short')).trigger('change.select2');
         }

      });
    });
   }


</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.product.productmain',['product_id'=>$id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/product/price.blade.php ENDPATH**/ ?>