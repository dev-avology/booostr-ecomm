

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'POS'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section>
  <div class="pos-main-area">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-8 pos-right-bar">
          <div class="pos-product-area">
            <div class="pos-search-bar-main-area">
              <div class="pos-search-bar">
                <div class="search-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M18.031 16.617l4.283 4.282-1.415 1.415-4.282-4.283A8.96 8.96 0 0 1 11 20c-4.968 0-9-4.032-9-9s4.032-9 9-9 9 4.032 9 9a8.96 8.96 0 0 1-1.969 5.617zm-2.006-.742A6.977 6.977 0 0 0 18 11c0-3.868-3.133-7-7-7-3.868 0-7 3.132-7 7 0 3.867 3.132 7 7 7a6.977 6.977 0 0 0 4.875-1.975l.15-.15z"/></svg>
                </div>
                <div class="search-input">
                  <form class="search_form" method="post" action="<?php echo e(route('seller.pos.search')); ?>">
                   <?php echo csrf_field(); ?>
                  <input type="text" name="src" required="" placeholder="Search Product" id="product_search">
                  </form>
                </div>
              </div>
            </div>
            <div class="product-categories-lists">
              <nav>
                <ul class="nav nav-pills " role="tablist">
                  <li   class="nav-item active category_item" data-id=""><a href="#" class="category-item"><?php echo e(__('ALL')); ?></a></li>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item category_item" data-id="<?php echo e($row->id); ?>"><a class="category-item" href="#" data-id="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </nav>
            </div>
            <div class="pos-product-main-content">
              <div class="row" id="product_list">
              </div>
              <div class="row">
                <div class="col-lg-6 offset-lg-3">
                  <div class="load-more text-center">
                    <a href="javascript:void(0)" class="load_more_btn none"><?php echo e(__('Load More')); ?></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="pos-right-area">
            <div class="customer-header-input">
              <div class="customer-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-4.987-3.744A7.966 7.966 0 0 0 12 20c1.97 0 3.773-.712 5.167-1.892A6.979 6.979 0 0 0 12.16 16a6.981 6.981 0 0 0-5.147 2.256zM5.616 16.82A8.975 8.975 0 0 1 12.16 14a8.972 8.972 0 0 1 6.362 2.634 8 8 0 1 0-12.906.187zM12 13a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm0-2a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/></svg>
              </div>
              <div class="customer-input">
                <input type="text" id="customer_email" name="customer_email" placeholder="Select Customers">
              </div>
            </div>
            <?php if(tenant('customer_modules') == 'on'): ?>
            <div class="add-new-customer-btn">
              <a href="javascript:void(0)" data-toggle="modal" data-target="#customer_create_modal"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M11 11V5h2v6h6v2h-6v6h-2v-6H5v-2z"/></svg></a>
            </div>
            <?php endif; ?>
          </div>
          <div class="form-group mt-3">
            <div class="barcode-input-area">
              <div class="input-group">
                <input type="text" class="barcode" placeholder="Enter product barcode">
              </div>
              <div class="barcode-icon">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path fill="none" d="M0 0h24v24H0z"/><path d="M2 4h2v16H2V4zm4 0h1v16H6V4zm2 0h2v16H8V4zm3 0h2v16h-2V4zm3 0h2v16h-2V4zm3 0h1v16h-1V4zm2 0h3v16h-3V4z"/></svg>
              </div>
            </div>
          </div>
          <div class="pos-item-lists">
            <div class="table-responsive">
              <table class="table table-striped">
                <tbody class="cart_table_body"><tr>
                  <th><?php echo e(__('Qty')); ?></th>
                  <th><?php echo e(__('Product')); ?></th>
                  <th><?php echo e(__('Price')); ?></th>
                  <th><?php echo e(__('Action')); ?></th>
                </tr>
              </tbody></table>
            </div>
          </div>
          <div class="pos-payable-amount">
            <div class="table-responsive">
              <table class="table table-striped">
                <tbody>
                <tr>
                  <th><strong><?php echo e(__('Subtotal')); ?></strong></th>
                  <th class="payable-right subtotal" ><?php echo e(Cart::subtotal()); ?></th>
                </tr>
                <tr>
                  <th><strong><?php echo e(__('Tax')); ?></strong></th>
                  <th class="payable-right tax"><?php echo e(Cart::tax()); ?></th>
                </tr>
                <tr>
                  <th><strong><?php echo e(__('Total(Payable)')); ?></strong></th>
                  <th class="payable-right total"><?php echo e(Cart::total()); ?></th>
                </tr>
              </tbody></table>
            </div>
          </div>
          <div class="pos-button">
           <button class="btn btn-primary" id="order_btn" type="button" data-toggle="modal" data-target="#ordermodal" ><?php echo e(__('Make Order')); ?></button>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- optionable product Modal -->
 <form class="option_form" method="post" action="<?php echo e(route('seller.add.tocart')); ?>">
<div class="modal fade" id="product_variation_modal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(__('Select Variation')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="tables-lists">
          <div class="row">
           <div class="col-sm-12 option_form_area">
             
           </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary add_to_cart_form_btn"><?php echo e(__('Add To Cart')); ?></button>
      </div>
    </div>
  </div>
</div>
</form>

<!-- optionable product Modal -->
 <form class="customer_store_form" method="post" action="<?php echo e(route('seller.pos.customer.store')); ?>">
  <?php echo csrf_field(); ?>
<div class="modal fade" id="customer_create_modal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(__('Create Customer')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="tables-lists">
          <div class="row">
           <div class="col-sm-12">
             <div class="form-group">
               <label><?php echo e(__('Name')); ?></label>
               <input type="text" name="name" class="form-control" required="">
             </div>
             <div class="form-group">
               <label><?php echo e(__('Email')); ?></label>
               <input type="email" name="email" class="form-control" required="">
             </div>
             <div class="form-group">
               <label><?php echo e(__('Password')); ?></label>
               <input type="password" name="password" class="form-control" required="">
             </div>
             <div class="form-group">
               <label><?php echo e(__('Wallet')); ?></label>
               <input type="number" value="0" step="any" name="wallet" class="form-control" required="">
             </div>
           </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary customer_create_btn"><?php echo e(__('Create Customer')); ?></button>
      </div>
    </div>
  </div>
</div>
</form>
 
<form method="post" class="ajaxform_with_reload" action="<?php echo e(route('seller.pos.order')); ?>">
  <?php echo csrf_field(); ?>
<!-- Modal -->
<div class="modal fade" id="ordermodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Make Order')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
        <input type="hidden" name="customer_id" id="customer_id">
        <div class="row">
        <div class="col-sm-2">
          <div class="form-group">
            <label><?php echo e(__('Select Payment Method')); ?></label>
            <div class="custom-switches-stacked ">
              <?php $__currentLoopData = $getways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $getway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label>
              <input type="radio" name="getway" value="<?php echo e($getway->id); ?>" class="custom-switch-input" <?php echo e($key == 0 ? 'checked' : ''); ?>>
              <span class="custom-switch-indicator"></span>
              <span class="custom-switch-description"><?php echo e($getway->name); ?></span>
            </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        </div>
        <div class="col-sm-6">
          <div class="pos-item-lists">
          <div class="table-responsive">
            <table class="table table-bordered  table-striped" >
              <thead>
                 <tr>
                  <th><?php echo e(__('Product Name')); ?></th>
                  <th class="text-right"><?php echo e(__('Price')); ?></th>
                </tr>
              </thead>
              <tbody class="cart_modal">

              </tbody>
            </table>
          </div>
        </div>
         <div class="table-responsive mt-2">
        <table class="table table-bordered table-striped table-condensed">
          <thead>
            <tr>
              <th class="text-left w-60" colspan="2"><?php echo e(__('Detail')); ?></th>
              <th class="text-right"><?php echo e(__('Price')); ?></th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th class="text-left w-60" colspan="2">
                <?php echo e(__('Subtotal')); ?>              
              </th>
              <td class="text-right w-40 subtotal "><?php echo e(Cart::subtotal()); ?></td>
            </tr>
            <tr>
              <th class="text-left w-60 " colspan="2">
                <?php echo e(__('Discount')); ?> 
              </th>
              <td class="text-right w-40 "><?php echo e(Cart::discount()); ?></td>
            </tr>
            <tr>
              <th class="text-left w-60" colspan="2">
                <?php echo e(__('Order Tax')); ?>             
              </th>
              <td class="text-right w-40 tax"><?php echo e(Cart::tax()); ?></td>
            </tr>
            <tr>
              <th class="text-left w-60 " colspan="2">
                <?php echo e(__('Shipping Charge')); ?> 
              </th>
              <td class="text-right w-40 shipping_charge">0.00</td>
              <input type="hidden" name="shipping_price" class="shipping_price">
            </tr>
            <tr>
              <th class="text-left w-60 " colspan="2">
                <?php echo e(__('Payable Amount')); ?>

              </th>
              
              <td class="text-right w-40 total"><?php echo e(Cart::total()); ?></td>
            </tr>
          </tfoot>
        </table>
        <div class="form-group">
            <label><b><?php echo e(__('Customer Name')); ?></b> </label>
            <input type="text" name="name" class="form-control customer_name">
        </div>
        <div class="form-group">
            <label><b><?php echo e(__('Customer Email')); ?></b> </label>
            <input type="email" name="email" class="form-control customer_email">
        </div>
        <div class="form-group">
            <label><b><?php echo e(__('Customer Phone')); ?></b> </label>
            <input type="tel" name="phone" class="form-control customer_phone">
        </div>
        <div class="form-group">
            <label><b><?php echo e(__('Order Note:')); ?></b> </label>
            <textarea class="form-control" name="note"></textarea>
        </div>
      </div>
      </div>
      <div class="col-sm-4">
        <div class="table-responsive">
        <table class="table table-bordered table-striped table-condensed">
          <tfoot>
            <tr>
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Select Order Method')); ?></b> </label>
                  <select class="selectric form-control order_method" name="order_method">
                    <option value="table"><?php echo e(__('Order From Table')); ?></option>
                    <option value="pickup"><?php echo e(__('Pickup Order')); ?></option>
                    <option value="delivery"><?php echo e(__('Delivery Order')); ?></option>
                  </select>
                </div>
              </td>
            </tr>
            <tr class="table_area">
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Select Table')); ?></b> </label>
                  <select class="selectric form-control" name="table">
                    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </td>
            </tr>
            <tr class="location_area none">
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Select Delivery Area')); ?></b> </label>
                  <select class="selectric form-control" name="location" id="location">
                    <option value="" data-shipping="[]"><?php echo e(__('Select Location')); ?></option>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>" data-shipping="<?php echo e($row->shipping); ?>"><?php echo e($row->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </td>
            </tr>
            <tr class="location_area none">
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Select Shipping Method')); ?></b> </label>
                  <select class="form-control" name="shipping_method" id="shipping_method">
                  <option value="" data-price="0"><?php echo e(__('Select Shipping Method')); ?></option>
                  </select>
                </div>
              </td>
            </tr>
            <tr class="location_area none">
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Delivery Address')); ?></b> </label>
                  <textarea class="form-control" name="delivery_address"></textarea>
                </div>
              </td>
            </tr>
            <tr>
              <td colspan="3">
                <div class="form-group">
                  <label><b><?php echo e(__('Is Pre Order?')); ?></b> </label>
                  <select class="selectric form-control pre_order" name="pre_order">
                    <option value="1"><?php echo e(__('Yes')); ?></option>
                    <option value="0" selected=""><?php echo e(__('No')); ?></option>
                  </select>
                </div>
              </td>
            </tr>
            <tr>
              <td colspan="3" class="date_time none">
                <div class="form-group">
                  <label><b><?php echo e(__('Select Date')); ?></b> </label>
                  <input type="date" name="date" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <td colspan="3" class="date_time none">
                <div class="form-group">
                  <label><b><?php echo e(__('Select Time')); ?></b> </label>
                  <input type="time" id="time" class="form-control">
                  <input type="hidden" name="time" class="time">
                </div>
              </td>
            </tr>
            <tr>
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Order Status')); ?></b> </label>
                  <select class="form-control selectric" name="order_status">
                    <?php $__currentLoopData = $order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </td>
            </tr>
            <tr>
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Payment Status')); ?></b> </label>
                  <select class="form-control selectric" name="payment_status">
                    <option value="1"><?php echo e(__('Paid')); ?></option>
                    <option value="2"><?php echo e(__('Pending')); ?></option>
                    <option value="0"><?php echo e(__('Faild')); ?></option>
                  </select>
                </div>
              </td>
            </tr>
            <tr>
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Payment Id')); ?></b> </label>
                  <input type="text" name="payment_id" class="form-control">
                </div>
              </td>
            </tr>
            <tr>
              <td colspan="3" >
                <div class="form-group">
                  <label><b><?php echo e(__('Coupon Code')); ?></b> </label>
                  <input type="text" name="coupon" class="form-control">
                </div>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
      </div>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary"><?php echo e(__('Checkout')); ?></button>
      </div>
    </div>
  </div>
</div>
</form>
<input type="hidden" id="product_link" value="<?php echo e(route('seller.product.json')); ?>"/>
<input type="hidden" id="defaut_img" value="<?php echo e(asset('uploads/default.png')); ?>" />
<input type="hidden" id="currency_name" value="<?php echo e(currency()); ?>" />
<input type="hidden" id="cart_link" value="<?php echo e(route('seller.add.tocart')); ?>" />
<input type="hidden" id="base_url" value="<?php echo e(url('/')); ?>" />
<input type="hidden" id="click_sound" value="<?php echo e(asset('uploads/click.wav')); ?>">
<input type="hidden" id="cart_sound" value="<?php echo e(asset('uploads/cart.wav')); ?>">
<input type="hidden" id="cart_increment" value="<?php echo e(url('/seller/cart-qty')); ?>">
<input type="hidden" id="pos_product_varidation" value="<?php echo e(url('/seller/product-varidation')); ?>">
<input type="hidden" id="cart_content" value="<?php echo e(Cart::content()); ?>">
<input type="hidden" class="total_amount" value="<?php echo e(str_replace(',','',Cart::total())); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin/js/pos.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/pos/pos.blade.php ENDPATH**/ ?>