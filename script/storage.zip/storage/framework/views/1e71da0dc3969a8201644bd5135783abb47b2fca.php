
<?php $__env->startSection('content'); ?>
<?php
$header_slider_status=$page_data->header_slider_status ?? 'yes';
$header_short_banner=$page_data->header_short_banner ?? 'yes';
$latest_product_status=$page_data->latest_product_status ?? 'yes';
$featured_category_status=$page_data->featured_category_status ?? 'yes';
$filter_product_status=$page_data->filter_product_status ?? 'yes';
$top_rated_product_status=$page_data->top_rated_product_status ?? 'yes';
$promotion_area_status=$page_data->promotion_area_status ?? 'yes';
$blog_area_status=$page_data->blog_area_status ?? 'yes';
$brand_area_status=$page_data->brand_area_status ?? 'yes';
?>

<?php if($header_slider_status == 'yes'): ?>

<section class="hero-area hero_slider_section" >
   <div class="hero-slider">
      <div class="content-preloader" >
         <div class="content-placeholder"   data-height="400px" data-width="100%"> </div>
      </div>
   </div>
</section>

<?php endif; ?>
<?php if($header_short_banner == 'yes'): ?>
<!-- Features -->
<section class="content-preloader">
<div class="container">
      <div class="row mt-3">
        <div class="col-lg-3 col-md-6 col-6  content-preloader" >
         <div class="content-placeholder"   data-height="250px" data-width="100%">
         </div>
      </div>
      <div class="col-lg-3 col-md-6 col-6  content-preloader" >
         <div class="content-placeholder"   data-height="250px" data-width="100%">
         </div>
      </div>
      <div class="col-lg-3 col-md-6 col-6  content-preloader" >
         <div class="content-placeholder"   data-height="250px" data-width="100%">
         </div>
      </div>
      <div class="col-lg-3 col-md-6 col-6  content-preloader" >
         <div class="content-placeholder"   data-height="250px" data-width="100%">
         </div>
      </div>
   </div>
</div>
</section>

<section class="features short_banner_section">
   <div class="container">
      <div class="row short_banner">

      </div>
   </div>
</section>
<!-- End Features -->
<!-- Products Area -->
<?php endif; ?>
<?php if($latest_product_status == 'yes'): ?>
<section class="products-area bg-second section-padding latest_product_section">
   <div class="container">
      <div class="row">
         <div class="col-lg-6 col-md-8 col-12">
            <div class="section-title m-btm-30">
               <p class="small-title font-stylish m-btm-10 pr-color"><?php echo e($page_data->latest_product_short_title ?? ''); ?></p>
               <h2 class="s-content-title"><?php echo e($page_data->latest_product_title ?? ''); ?></h2>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-12">
            <div class="product-area-main">
               <div class="single-product-top product-latest-slider latest_products_preloader">
               </div>
               <div class="single-product-top product-latest-slider latest_products">
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php endif; ?>

<?php if($featured_category_status == 'yes'): ?>
<!-- Category Area Start -->
<section class="featured_category category_section">
   <div class="category-area">
      <div class="container">
         <div class="row">
            <div class="col-lg-12">
               <div class="category-header">
                  <h2><?php echo e($page_data->featured_category_title ?? ''); ?></h2>
               </div>
            </div>
         </div>
         <div class="row department-slider">
           
           
         </div>
      </div>
   </div>
</section>
<!-- Category Area end -->
<?php endif; ?>

<?php if($filter_product_status == 'yes'): ?>
<!-- Product Home Tab -->
<section class="product-home-tabs bg-second section-padding product_tab_section">
   <div class="container">
      <div class="row">
         <div class="col-lg-6 offset-md-3 col-md-8 offset-md-2 col-12 wow fadeInUp"  data-wow-delay=".3s">
            <div class="section-title m-btm-30 text-center">
               <p class="small-title font-stylish m-btm-10 pr-color"><?php echo e($page_data->filter_product_short_title ?? ''); ?></p>
               <h2 class="s-content-title"><?php echo e($page_data->filter_product_title ?? ''); ?></h2>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-12 wow fadeInUp"  data-wow-delay=".5s">
            <!-- Tab Menu -->
            <div class="latest-home-tabs">
               <ul class="list-group product_menu" id="list-tab" role="tablist">
                 <li><a class="list-group-item active" data-bs-toggle="list" href="#f-tab1" role="tab"><?php echo e(__('All')); ?> </a></li>
                 
               </ul>
            </div>
            <!-- End Tab Menu -->
         </div>
         <div class="col-12">
            <!-- Tab Details -->
            <div class="latest-tab-details m-top-30">
               <div class="tab-content" id="nav-tabContent">
                  <!-- Property Tab One -->
                  <div class="tab-pane fade show active tab1" id="f-tab1" role="tabpanel">
                      <div class="row random_products_preload">
                        
                       
                        
                       
                     </div>
                     <div class="row random_products">
                        
                       
                        
                       
                     </div>
                  </div>
                 
                  <!-- Property Tab Two -->
                  <div class="tab-pane fade tab2" id="f-tab2" role="tabpanel">
                     <div class="row filtered_product_tab">
                        
                     </div>
                  </div>

                
               </div>
            </div>
            <!-- End Tab Details -->
         </div>
      </div>
   </div>
</section>
<!-- End Product Home Tab -->
<!-- Products Area -->
<div class="featured_products_area">
   
</div>
<?php endif; ?>
<!-- End Products Area -->
<!-- Products Area -->
<?php if($top_rated_product_status == 'yes'): ?>
<section class="products-area bg-second section-padding toprated_products_area">
   <div class="container">
      <div class="row">
         <div class="col-lg-6 col-md-8 col-12">
            <div class="section-title m-btm-30">
               <p class="small-title font-stylish m-btm-10 pr-color"><?php echo e($page_data->top_rated_product_short_title ?? ''); ?></p>
               <h2 class="s-content-title"><?php echo e($page_data->top_rated_product_title ?? ''); ?></h2>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-12">
            <div class="product-area-main">
               <div class="single-product-top product-latest-slider toprated_products_preload">

                 
                  
               </div>
               <div class="single-product-top product-latest-slider toprated_products">

                 
                  
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php endif; ?>
<!-- End Products Area -->
<!-- Call to action -->
<?php if($promotion_area_status == 'yes'): ?>
<div class="cta-main section-padding">
   <div class="container">
      <div class="row d-flex align-items-center justify-content-center">
         <div class="col-lg-5 col-md-5 col-12 wow fadeInLeft"  data-wow-delay=".2s">
            <div class="food-ct-img">
               <img class="lazy" src="<?php echo e(asset('uploads/preload.webp')); ?>" data-src="<?php echo e(asset($page_data->promotion_banner ?? '')); ?>" alt="">
               <a href="<?php echo e($page_data->promotion_video_link ?? ''); ?>" class="video-btn video video-popup mfp-fade"><i class="icofont-ui-play"></i></a>
            </div>
         </div>
         <div class="col-lg-7 col-md-7 col-12 wow fadeInRight"  data-wow-delay=".4s">
            <div class="cta-content">
               <span><?php echo e($page_data->promotion_short_title ?? ''); ?></span>
               <h2><?php echo e($page_data->promotion_title ?? ''); ?></h2>
               <p><?php echo e($page_data->promotion_description ?? ''); ?></p>
               <div class="food-dt-button">
                  <a href="<?php echo e($page_data->promotion_link ?? ''); ?>" class="theme-btn primary"><?php echo e($page_data->promotion_button_title ?? ''); ?></a>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php endif; ?>
<!-- End Call to action -->
<!-- Blog Area -->
<?php if($blog_area_status == 'yes'): ?>
<section class="blog-area bg-second section-padding blog_section">
   <div class="container">
      <div class="row">
         <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12 wow fadeInDown"  data-wow-delay=".2s">
            <div class="section-title text-center m-btm-50">
               <p class="small-title font-stylish m-btm-10 pr-color"><?php echo e($page_data->blog_area_short_title ?? ''); ?></p>
               <h2 class="s-content-title"><?php echo e($page_data->blog_area_title ?? ''); ?></h2>
            </div>
         </div>
      </div>
      <div class="row latest_blogs">
      </div>
   </div>
</section>

<?php endif; ?>
<!-- End Blog Area -->
<?php if($brand_area_status == 'yes'): ?>
<!-- Partner Area -->
<div class="partner-area gr-overlay section-padding brand_section" style="background-image:url(<?php echo e(asset($page_data->brand_area_background ?? '')); ?>)">
   <div class="container">
      <div class="row">
         <div class="col-lg-4 col-12">
            <div class="section-title s-white-title text-center m-btm-50">
               <p class="small-title font-stylish m-btm-10 pr-color"><?php echo e($page_data->brand_area_short_title ?? ''); ?></p>
               <h2 class="s-content-title"><?php echo e($page_data->brand_area_title ?? ''); ?></h2>
            </div>
         </div>
         <div class="col-lg-8 col-12">
            <div class="partner-slider">
            </div>
         </div>
      </div>
   </div>
</div>
<?php endif; ?>
<!-- End Partner Area -->
<!-- Modal -->
 <?php echo $__env->make('theme.grshop.components.quickview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Modal end -->
<input type="hidden" id="blog_read_more" value="<?php echo e(__('Learn More')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('theme/jquery.unveil.js')); ?>"></script>
<script src="<?php echo e(asset('theme/grshop/js/home.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.grshop.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/index.blade.php ENDPATH**/ ?>