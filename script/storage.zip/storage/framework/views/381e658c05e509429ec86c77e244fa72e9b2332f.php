<!--  Footer -->
      <footer class="footer-area">
         <!--  Footer Top -->
         <div class="footer-top bg-full">
            <div class="container">
               <div class="row">
                  <div class="col-lg-3 col-md-6 col-12">
                     <!-- Footer Widget -->
                     <div class="footer-widget footer-about">
                        
                        <?php echo e(content_format($site_settings->footer_column1 ?? '')); ?>

                     </div>
                     <!-- End Footer Widget -->
                  </div>
                  <div class="col-lg-3 col-md-6 col-12">
                     <!-- Footer Widget -->
                     <div class="footer-widget footer-links">
                       <?php echo e(content_format($site_settings->footer_column2 ?? '')); ?>

                     </div>
                     <!-- End Footer Widget -->
                  </div>
                  <div class="col-lg-3 col-md-6 col-12">
                     <!-- Footer Widget -->
                     <div class="footer-widget footer-links">
                        <?php echo e(content_format($site_settings->footer_column3 ?? '')); ?>

                     </div>
                     <!-- End Footer Widget -->
                  </div>
                  <div class="col-lg-3 col-md-6 col-12">
                     <!-- Footer Widget -->
                     <div class="footer-widget newslatter">
                         <?php echo e(content_format($site_settings->footer_column4 ?? '')); ?>

                         <?php
                         $news_status=$site_settings->newsletter_status ?? 'no';
                         ?>
                         <?php if($news_status == 'yes'): ?>
                        <div class="newsletter-inner">
                           <form  method="post" class="newsletter-area ajaxform_with_reset" action="<?php echo e(route('customer.subscribe')); ?>">
                              <?php echo csrf_field(); ?>
                              <input type="email" name="email" placeholder="Your email address">
                              <button type="submit" class="basicbtn"><?php echo e(__('Subscribe Now')); ?></button>
                           </form>
                        </div>
                        
                        <?php endif; ?>
                     </div>
                     <!-- End Footer Widget -->
                  </div>
               </div>
            </div>
         </div>
         <!-- End Footer Top -->
         <!-- Copyright -->
         <div class="copyright">
            <div class="container">
               <div class="row ">
                  <div class="col-lg-6 col-md-6 col-12">
                     <?php echo e(content_format($site_settings->bottom_left_column ?? '')); ?>

                  </div>
                  <div class="col-lg-6 col-md-6 col-12">
                     
                     <?php echo e(content_format($site_settings->bottom_right_column ?? '')); ?>

                  </div>
               </div>
            </div>
         </div>
         <!-- End Copyright -->
      </footer>
      <!-- End Footer --><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/layouts/footer.blade.php ENDPATH**/ ?>