<?php if(!empty($menus)): ?>
<?php if(!empty($menus['data'] ?? [])): ?>
<div class="all-category">
   <h3 class="cat-heading">
      <b class="start-icon"><i class="icofont-navigation-menu" aria-hidden="true"></i></b>
      <span class="megamenu_name"><?php echo e($menus['name'] ?? ''); ?></span>
      <b class="down-icon"><i class="icofont-caret-down"></i></b>
   </h3>
   <ul class="main-category main-menu-cat">
      <?php $__currentLoopData = $menus['data'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
         <?php if(isset($row->children)): ?>
         <li>
         <a  href="javascript:void(0)" >
            <?php echo e($row->text); ?>  
            <i class="icofont-caret-right"></i>
         </a>
         <ul class="sub-category" >
            <?php $__currentLoopData = $row->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childrens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php echo $__env->make('theme.grshop.components.megamenu.child', ['childrens' => $childrens], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
         </li>
         <?php else: ?>

         <li><a  href="<?php echo e($row->href); ?>" <?php if(!empty($row->target)): ?> target="<?php echo e($row->target); ?>" <?php endif; ?>><?php echo e($row->text); ?> </a></li>
         <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
     
   </ul>
</div>
<?php endif; ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/components/megamenu/parent.blade.php ENDPATH**/ ?>