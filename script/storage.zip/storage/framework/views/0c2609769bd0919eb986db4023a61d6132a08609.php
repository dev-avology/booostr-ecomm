<?php if(env('CONTENT_EDITOR') == true): ?>
<?php echo $data; ?>

<?php else: ?>
<?php echo e($data); ?>

<?php endif; ?>
<?php /**PATH C:\wamp64\www\avology\script\resources\views/components/content.blade.php ENDPATH**/ ?>