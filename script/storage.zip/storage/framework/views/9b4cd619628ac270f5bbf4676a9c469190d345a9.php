<!DOCTYPE html>
  <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      
      <?php echo SEOMeta::generate(); ?>

      <?php echo OpenGraph::generate(); ?>

      <?php echo Twitter::generate(); ?>

      <?php echo JsonLd::generate(); ?>

      <?php echo JsonLdMulti::generate(); ?>

      <?php echo SEO::generate(true); ?>


      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('uploads/'.tenant('uid').'/favicon.ico')); ?>">
      <!-- Web Font -->
         
      <!-- Google Font -->
      <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,500;1,600;1,700&display=swap" rel="stylesheet">   
      
      <!-- Bootstrap -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/bootstrap.min.css')); ?>">
      <!-- Owl Carousel -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/owl.carousel.min.css')); ?>">
      <!-- Jquery UI CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/maginific-popup.min.css')); ?>">
      <!-- Jquery UI CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/perfect-scroolbar.css')); ?>">
      <!-- Jquery UI CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/jquery-ui.css')); ?>">
      <!-- Flex Slider CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/flex-slider.css')); ?>">
      <!-- Nice select CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/nice-select.css')); ?>">
      <!-- Animate CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/animate.min.css')); ?>">
      <!-- Slicknav CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/slicknav.min.css')); ?>">
      <!-- Icofont -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/css/icofont.css')); ?>">
      
      <!-- Main CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/reset.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/header.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/hero-area.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/partner.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/departments.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/cart.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/cart-sidebar.css')); ?>">

      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/blog.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/shop-form.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/shop-single.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/checkout.css')); ?>">

      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/shop-form.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/banner-img.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/newsletter.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/latest-product.css')); ?>">

      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/modal.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/latest-product-tabs.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/shop-sidebar.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('theme/grshop/section/footer.css')); ?>">




      
      <link rel="stylesheet" href="<?php echo e(asset('theme/helper.css')); ?>">
      <?php echo $__env->yieldPushContent('css'); ?>
      <?php echo e(load_header()); ?>


    
   </head>
   <body>
     <?php
     $autoload_data=getautoloadquery();
     $average_times=optionfromcache('average_times');
    
     $cart_count=Cart::instance('default')->count();
     $wishlist_count=Cart::instance('wishlist')->count();
     ?>
      <!--[if lte IE 9]>
      <p class="browserupgrade">
         You are using an <strong>outdated</strong> browser. Please
         <a href="https://browsehappy.com/">upgrade your browser</a> to improve
         your experience and security.
      </p>
     <![endif]-->
      <?php if(isset($autoload_data['site_settings'])): ?>
      <?php
      $site_settings=json_decode($autoload_data['site_settings']);
      $site_settings=$site_settings->meta ?? '';
      $preloader=$site_settings->preloader ?? 'yes';
      ?>

      

      <?php endif; ?>

     <?php echo $__env->make('theme.grshop.layouts.header',['autoload_data'=>$autoload_data,'cart_count'=>$cart_count,'wishlist_count'=>$wishlist_count,'average_times'=>$average_times,'site_settings'=>$site_settings ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->yieldContent('content'); ?>
     <?php echo $__env->make('theme.grshop.layouts.footer',['site_settings'=>$site_settings ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <?php if(isset($autoload_data['whatsapp_settings'])): ?>
     <?php
     $whatsapp= json_decode($autoload_data['whatsapp_settings'])
     ?>
     <?php if($whatsapp->whatsapp_status == 'on'): ?>
       <?php echo $__env->make('components.whatsapp',['whatsapp'=>$whatsapp], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php endif; ?>
     <?php endif; ?>
<!--  scroll-top -->

<input type="hidden" id="callback_url" value="<?php echo e(route('callback.data')); ?>">  
<input type="hidden" id="cart_link" value="<?php echo e(route('add.tocart')); ?>" />
<input type="hidden" id="base_url" value="<?php echo e(url('/')); ?>" />
<input type="hidden" id="click_sound" value="<?php echo e(asset('uploads/click.wav')); ?>">
<input type="hidden" id="cart_sound" value="<?php echo e(asset('uploads/cart.wav')); ?>">
<input type="hidden" id="cart_increment" value="<?php echo e(url('/cart-qty')); ?>">
<input type="hidden" id="pos_product_varidation" value="<?php echo e(url('/product-varidation')); ?>">
<input type="hidden" id="cart_content" value="<?php echo e(Cart::content()); ?>">

<input type="hidden" class="total_amount" value="<?php echo e(str_replace(',','',Cart::total())); ?>">
<input type="hidden" id="preloader" value="<?php echo e(asset('uploads/preload.webp')); ?>">
<input type="hidden" id="currency_settings" value="<?php echo e($autoload_data['currency_data'] ?? ''); ?>">

<!-- Jquery JS -->
<script src="<?php echo e(asset('theme/grshop/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/grshop/js/jquery-migrate.js')); ?>"></script>
<script src="<?php echo e(asset('theme/grshop/js/jquery-ui.min.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('theme/grshop/js/bootstrap.min.js')); ?>"></script>
<!-- Wow JS -->
<script src="<?php echo e(asset('theme/grshop/js/wow.min.js')); ?>"></script>
<!-- Nice Select JS -->
<script src="<?php echo e(asset('theme/grshop/js/nice-select.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('theme/grshop/js/magnific-popup.min.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('theme/grshop/js/perfect-scroolbar.min.js')); ?>"></script>
<!-- Final Countodwn JS -->
<script src="<?php echo e(asset('theme/grshop/js/final-countdown.min.js')); ?>"></script>
<!-- Slick Nav JS -->
<script src="<?php echo e(asset('theme/grshop/js/jquery.slicknav.min.js')); ?>"></script>
<!-- Flex Slider JS -->
<script src="<?php echo e(asset('theme/grshop/js/flex-slider.js')); ?>"></script>
<!-- Owl Carousel JS -->
<script src="<?php echo e(asset('theme/grshop/js/owl.carousel.min.js')); ?>"></script>
<!-- Scroll UP Min -->
<script src="<?php echo e(asset('theme/grshop/js/scrollup.min.js')); ?>"></script>
<!-- Main JS -->
<script src="<?php echo e(asset('theme/grshop/js/active.js')); ?>"></script>
<script src="<?php echo e(asset('theme/helper.js?v=1.0')); ?>"></script>
<script src="<?php echo e(asset('theme/grshop/js/theme-helper.js')); ?>"></script>


<?php echo $__env->yieldPushContent('js'); ?>
<?php echo e(load_footer()); ?>

  </body>
</html><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/layouts/app.blade.php ENDPATH**/ ?>