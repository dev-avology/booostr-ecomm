<?php if($childrens): ?>
<li >
	<?php if(isset($childrens->children)): ?> 
	<a  <?php if(url()->current() == url($row->href)): ?> class="active" <?php endif; ?> href="<?php echo e(url($childrens->href)); ?>" <?php if(!empty($childrens->target)): ?> target=<?php echo e($childrens->target); ?> <?php endif; ?> >
		<?php echo e($childrens->text); ?></b>
		
	</a>
	
	<ul class="dropdown" >
		<?php $__currentLoopData = $childrens->children ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo $__env->make('theme.grshop.components.menu.child', ['childrens' => $row], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</ul>
	<?php else: ?>
	<a href="<?php echo e(url($childrens->href)); ?>"><?php echo e($childrens->text); ?></a>
	<?php endif; ?>
</li>
<?php endif; ?>


<?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/components/menu/child.blade.php ENDPATH**/ ?>