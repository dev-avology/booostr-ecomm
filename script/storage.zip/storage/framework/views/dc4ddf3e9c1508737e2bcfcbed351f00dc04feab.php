 <a href="#" data-toggle="modal" data-target=".media-single" class="text-dark single-modal media_radio" data-inputid="<?php echo e($input_id); ?>" data-previewclass="<?php echo e($preview_class); ?>">
    <label for="category-image" class="custom-label text-center">
        <div>
            <img  height="100px" class="<?php echo e($preview_class); ?>" src="<?php echo e(asset(empty($preview) ? 'admin/img/img/placeholder.png' : $preview)); ?>" alt="">
        </div>
        <span class="text-success">Upload </span> or a select image
    </label>
    <div class="image-previewer-pane">
     <input type="hidden" name="<?php echo e($input_name); ?>"  id="<?php echo e($input_id); ?>" value="<?php echo e($value); ?>">
 </div>
</a><?php /**PATH C:\wamp64\www\avology\script\resources\views/components/media/section1.blade.php ENDPATH**/ ?>