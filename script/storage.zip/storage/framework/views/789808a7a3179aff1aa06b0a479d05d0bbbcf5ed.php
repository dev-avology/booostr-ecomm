<?php if(tenant('custom_css_js') == 'on'): ?>
<?php if(file_exists('uploads/'.tenant('uid').'/custom.css')): ?>
<script src="<?php echo e(asset('uploads/'.tenant('uid').'/custom.css?v='.tenant('cache_version'))); ?>"></script>
<?php endif; ?>
<?php endif; ?>


<?php if(tenant('pwa') == 'on'): ?>
<?php if(file_exists('uploads/'.tenant('uid').'/manifest.json')): ?>
<link rel="manifest"  href="<?php echo e(asset('uploads/'.tenant('uid').'/manifest.json?v='.tenant('cache_version'))); ?>">
<?php endif; ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/components/load_header.blade.php ENDPATH**/ ?>