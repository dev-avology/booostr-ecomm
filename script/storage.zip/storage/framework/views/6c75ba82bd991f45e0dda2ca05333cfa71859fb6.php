

<?php $__env->startPush('css'); ?>

<!-- CSS Libraries -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/dropzone/dropzone.css')); ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@x.x.x/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@x.x.x/dist/css/bootstrap-select.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    
    <div class="section-header">
        <a href="<?php echo e(url('seller/coupon')); ?>" class="btn btn-primary mr-2">
            <i class="fas fa-arrow-left"></i>
        </a>
        <h1><?php echo e(__('Create Coupon')); ?></h1>
    </div>
    
    <div class="row">
        <div class="col-lg-12">
            <form class="ajaxform_with_reset" method="post" action="<?php echo e(route('seller.coupon.store')); ?>">
                <?php echo csrf_field(); ?>
                
                <div class="row">
                    
                    <div class="col-lg-5">
                    <strong><?php echo e(__('Coupon Basics Information')); ?></strong>
                        <p><?php echo e(__('Add your coupon Basics information from here')); ?></p>
                    </div>
                    
                    
                    <div class="col-lg-7">
                    <div class="card">
                        <div class="card-body">

                                    <div class="from-group row mb-2">
                                        <label for="" class="col-lg-12"><?php echo e(__('Coupon code is for discount off')); ?> </label>
                                        <div class="col-lg-12">
                                            <select class="form-control" name="coupon_first" id="coupon_first" required>
                                                <option value="all" selected><?php echo e(__('Total order amount')); ?></option>
                                                <option value="specific_product_or_cat"><?php echo e(__('Specific products/Categories')); ?></option>
                                            </select>
                                        </div>
                                    </div>

                                    

                                    <div class="form-group row mb-2" style="display:none;" id="specific-cat-pro">
                                        <label for="" class="col-lg-12"><?php echo e(__('Choose Specific products/Categories')); ?> </label>
                                        <div class="col-lg-12">
                                            <select class="form-control" data-live-search="true" name="choose_specific_product_or_category" id="coupon_for"> 
                                                <option value="" selected disabled><?php echo e(__('Choose Specific products')); ?></option>
                                                <option value="product"><?php echo e(__('Specific products')); ?></option>
                                                <option value="category"><?php echo e(__('Specific categories')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row mb-2 hide-all-coupon-value" style="display:none;">
                                        <label for="" id="specific-label" class="col-lg-12"><?php echo e(__('Choose Specific products')); ?> </label>
                                        <div class="col-lg-12">
                                            <select class="form-control selectpicker" multiple data-live-search="true" name="coupon_id[]" id="coupon_id">
                                                <!-- Remove the 'Select' option as it is not needed for multi-select -->
                                            </select>
                                        </div>
                                    </div> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-5">
                    <strong><?php echo e(__('Coupon Details:')); ?></strong>
                        <p><?php echo e(__('Add your coupon details and necessary information from here')); ?></p>
                    </div>
                    
                    
                    <div class="col-lg-7">
                    <div class="card">
                        <div class="card-body">
                            
                                    <div class="from-group row mb-2">
                                        <label for="" class="col-lg-12"><?php echo e(__('Coupon Code Name/Title')); ?> </label>
                                        <div class="col-lg-12">
                                            <input type="text" required name="code_name" class="form-control" placeholder="Enter Name/Title">
                                        </div>
                                    </div>

                                    <div class="from-group row mb-2">
                                        <label for="" class="col-lg-12"><?php echo e(__('Coupon Code')); ?> </label>
                                        <div class="col-lg-9">
                                            <input type="text" required name="code" class="form-control" placeholder="Enter Coupon Code">
                                        </div>
                                        <div class="col-lg-3 gen-cpn-div">
                                            <a class="btn btn-primary generate-cpn">Generate code</a>
                                        </div>
                                    </div>


                                    <div class="from-group row mb-2">
                                        <label for="" class="col-lg-12" id="discountTypelable"><?php echo e(__('Order Total:')); ?> </label>
                                        <div class="col-lg-12">
                                            <select class="form-control" name="discount_type" id="discount_type" required>
                                                <option value="" selected disabled><?php echo e(__('Choose dollar off or percent off')); ?></option>
                                                <option value="0"><?php echo e(__('Dollar off')); ?></option>
                                                <option value="1"><?php echo e(__('Percent off')); ?></option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="from-group row mb-2" style="display:none;" id="discount-amount-hide">
                                        <label for="" class="col-lg-12">Discount Amount</label>
                                        <div class="col-lg-12 discountAmount input-with-icon">
                                           <i class="fas "></i>
                                           <input type="text"  required="" value="0" 
                                           step="any" name="price" class="form-control" id="maskprice"  placeholder="Enter percent off or doller off">
                                        </div>
                                    </div>
                                    

                                    <div class="from-group row mb-2" id="min_amount_area">
                                        <label for="" class="col-lg-12"><?php echo e(__('Minimum purchase requirements:')); ?> </label>
                                        <div class="col-lg-12">
                                            <select class="form-control" name="min_amount_option" id="min_amount_option">

                                                <option value="0"> No minimum requirements </option>

                                                <option value="1"><?php echo e(__('Minimum purchase amount ($)')); ?></option>
                                                <option value="2"><?php echo e(__('Minimum quantity of items')); ?></option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="from-group row mb-2" id="min_amount_val" style="display:none;">
                                        <label for="" class="col-lg-12"><?php echo e(__('Enter minimum amount:')); ?> </label>
                                        <div class="col-lg-12 minAmount input-with-icon">
                                            <i class="fas "></i>
                                            <input type="number" step="any" name="min_amount" class="form-control" placeholder="" id ="min_amount_mask">
                                            <span class="applied-text" style="font-size:10px;">Applies only to selected products. OR Applies only to selected categories. (depends on if they selected products or categories)</span>
                                        </div>
                                       
                                    </div>

                                    <div class="from-group row mb-2">
                                        <label for="" class="col-lg-7"><?php echo e(__('Limit Number of times discount can be used:')); ?> </label>
                                        <div class="col-lg-4">
                                            <input class="tgl tgl-light" id="max_use_checkbox" type="checkbox"/>
                                        </div>
                                    </div>


                                    <div class="from-group row mb-2" id="max_use_value" style="display:none;">
                                        <div class="col-lg-12">
                                            <input type="number" name="max_use" value="0" class="form-control" placeholder="Add the number of times it can be used">
                                        </div>
                                    </div>
                                    
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    
                    <div class="col-lg-5">
                    <strong><?php echo e(__('Coupon Scheduling:')); ?></strong>
                        <p><?php echo e(__('Add your coupon Scheduling from here')); ?></p>
                    </div>
                    
                    
                    <div class="col-lg-7">
                    <div class="card">
                        <div class="card-body">
                            
                                <div class="from-group row mb-2" >
                                    <label for="" class="col-lg-12"><?php echo e(__('Start From:')); ?> </label>
                                    <div class="col-lg-12">
                                        <input type="datetime-local" name="start_from" class="form-control" >
                                    </div>
                                </div>


                                    <div class="from-group row mb-2">
                                        <label for="" class="col-lg-12"><?php echo e(__('Expiration date:')); ?> </label>
                                        <div class="col-lg-12">
                                            <div class="coupon-checkbox-wrapper-6">
                                                <input class="tgl tgl-light" id="cb1-6" type="checkbox"/>
                                                
                                                <label class="tgl-btn" for="cb1-6">
                                            </div>
                                        </div>
                                        <input type="hidden" name="date_checkbox" id="date_checkbox"/>
                                    </div>



                                    <div class="from-group row mb-2 coupon-hidden-date" style="display:none;">
                                        <label for="" class="col-lg-12"><?php echo e(__('Will Expire:')); ?> </label>
                                        <div class="col-lg-12">
                                            <input type="datetime-local" name="will_expire" class="form-control" >
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <button class="btn btn-primary basicbtn" type="submit"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>

               
            </form>
        </div>
    </div>
</section>
<?php echo e(mediasingle()); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
 <!-- JS Libraies -->
<script src="<?php echo e(asset('admin/plugins/dropzone/dropzone.min.js')); ?>"></script>
<!-- Page Specific JS File -->
<script src="<?php echo e(asset('admin/plugins/dropzone/components-multiple-upload.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/seller.js')); ?>"></script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@x.x.x/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@x.x.x/dist/js/bootstrap-select.min.js"></script>

<script>

    $('.generate-cpn').click(function(){
        $.ajax({
            type: "GET",
            url: '<?php echo e(url("generate-coupon-code")); ?>',
            success: function(response) {
                if(response.status==200){
                    $('input[name="code"]').val(response.code);
                }
            },
            error: function(error) {
            }
        });
    })

    $(document).ready(function() {
        Inputmask("9{0,2}.9{0,3}", {
        placeholder: "5.00", 
        greedy: true
        }).mask('#maskprice');


        $(document).on('change', '#maskprice', function () {
            var discountType = $('#discount_type').val();
            if(discountType==0){
                var inputValue = $(this).val();
                inputValue = inputValue.match(/[0-9.]+/g);
                if (inputValue === null || inputValue === '') {
                    return;
                }
                $(this).val(parseFloat(inputValue).toFixed(2));
            }
        });

        $(document).on('change', '#min_amount_mask', function () {
            var minAmount = $('#min_amount_option').val();
            if(minAmount==1){
                var inputValue = $(this).val();
                inputValue = inputValue.match(/[0-9.]+/g);
                if (inputValue === null || inputValue === '') {
                    return;
                }
                $(this).val(parseFloat(inputValue).toFixed(2));
            }
        });

        $('#coupon_first').change(function(){
            var coupon_first = $(this).val();
            if(coupon_first == 'specific_product_or_cat'){
                    $('#specific-cat-pro').css('display','block');
                    $('#discountTypelable').text('Products/Categories');
            }else{
                  $('#discountTypelable').text('Order Total');
                    $('#specific-cat-pro').css('display','none');
                    $('.hide-all-coupon-value').css('display','none');
            }
        })

        $("#cb1-6").change(function () {
            $(".coupon-hidden-date").toggle($(this).is(":checked"));
            var isChecked = $(this).is(":checked");

            if(isChecked){
                $('#date_checkbox').val(1);
            }
        });

        $("#max_use_checkbox").change(function () {
            $("#max_use_value").toggle($(this).is(":checked"));
        });

        $("#min_amount_option").change(function () {

            var icon =  $('.minAmount.input-with-icon i');
            
            // $('.input-with-icon i').remove();
            var inputValue = $('#min_amount_mask').val();
            var min_amount_check = $(this).val();

            if (min_amount_check == 1) {
                $('#min_amount_val').css('display', 'block');

                icon.addClass('fa-dollar-sign');

                // var iconElement = $('<i class="fas fa-dollar-sign"></i>');
                // $('.input-with-icon input[name="min_amount"]').before(iconElement);

                inputValue = inputValue.match(/[0-9.]+/g);
                if (inputValue === null || inputValue === '') {
                    return;
                }
                $('#min_amount_mask').val(parseFloat(inputValue).toFixed(2)); 

            } else if (min_amount_check == 2) {
                icon.removeClass('fa-dollar-sign');
                $('#min_amount_val').css('display', 'block');
                $('#min_amount_val').css('display', 'block');
                $('#min_amount_mask').val(inputValue.replace(/\.00$/, ''))
            }else{
                $('#min_amount_val').css('display', 'none');
            }
        });

        $("#discount_type").change(function () {
            // $('.input-with-icon i').remove();
            var inputValue = $('#maskprice').val();

            var icon =  $('.discountAmount.input-with-icon i');
            var discount_type = $(this).val();

            if(discount_type==0){

                $('#discount-amount-hide').css('display','block');
                $('#discount-amount-hide label').text('Enter discount amount in doller($)');

                inputValue = inputValue.match(/[0-9.]+/g);
                if (inputValue === null || inputValue === '') {
                    return;
                }

                $('#maskprice').val(parseFloat(inputValue).toFixed(2)); 
                if(icon.hasClass('fa-percent'))
                icon.removeClass('fa-percent');

                icon.addClass('fa-dollar-sign');

                // var iconElement = $('<i class="fas fa-dollar-sign"></i>');
                // $('.input-with-icon input[name="price"]').before(iconElement);

            }else if(discount_type==1){

                $('#discount-amount-hide').css('display','block');
                $('#discount-amount-hide label').text('Enter discount amount in percent(%)');

                // var iconElement = $('<i class="fas fa-percent"></i>');
                // $('.input-with-icon input[name="price"]').before(iconElement);
                if(icon.hasClass('fa-dollar-sign'))
                icon.removeClass('fa-dollar-sign');

                icon.addClass('fa-percent');

                $('#maskprice').val(inputValue.replace(/\.00$/, ''))
            }else{
                $('#discount-amount-hide').css('display','none');
                $('#discount-amount-hide label').text('');
            }
        });

            // Initialize Bootstrap Select
        $('.selectpicker').selectpicker();

        $('#coupon_for').change(function() {
            var selectedValues = $(this).val();

            if (selectedValues && selectedValues.includes('all')) {
                $('.hide-all-coupon-value').css('display', 'none');
            }
    
            if(selectedValues == 'product'){
                $('#discountTypelable').text('Products');
            }else if(selectedValues == 'category'){
                $('#discountTypelable').text('Categories');
            }else{
                $('#discountTypelable').text('Products/Categories');
            }
             

            if (selectedValues && (selectedValues.includes('product') || selectedValues.includes('category'))) {
                $.ajax({
                    type: "GET",
                    url: '<?php echo e(url("get-coupon-type")); ?>' + '/' + selectedValues,
                    success: function(data) {
                        $('#coupon_id').empty();
                        $('.hide-all-coupon-value').css('display', 'block');

                        // var defaultOptionText = '';
                        var specificLabel = '';

                        $.each(data['term'], function(key, value) {
                            if (data['type'] == 'product') {
                                // defaultOptionText = 'Select product';
                                specificLabel = 'Choose specific products';
                                $('#specific-label').text(specificLabel);
                                $('#coupon_id').append('<option value="' + value.id + '">' + value.title + '</option>');
                            } else if (data['type'] == 'category') {
                                // defaultOptionText = 'Select category';
                                specificLabel = 'Choose specific categories';
                                $('#specific-label').text(specificLabel);
                                $('#coupon_id').append('<option value="' + value.id + '">' + value.name + '</option>');
                            }
                        });

                        // Refresh Bootstrap Select after updating options
                        $('#coupon_id').selectpicker('refresh');
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            }
        });     
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/coupon/create.blade.php ENDPATH**/ ?>