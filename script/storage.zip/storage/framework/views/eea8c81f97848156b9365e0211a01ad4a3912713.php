<style>
    .row {
        /* height: 79px;
        width: 572px;
        margin-left: 266px;
        margin-top: 43px;
        border-radius: 10px 10px 0 0; */
        background-color: rgb(0, 192, 255);
        /* display: inline-flex; */
        }
</style>


<tr class="row">
    <td class="header">
        <table width="50%" cellpadding="0" cellspacing="0">
            <tr>
                <td>
                    <a href="" style="display: inline-block;">
                        <?php if(!empty(tenant()->logo)): ?>
                            <img src="<?php echo e(env('WP_URL')); ?><?php echo e(tenant()->logo); ?>" height="80" width="160" />
                        <?php endif; ?>
                    </a>
                </td>
            </tr>
        </table>
    </td>
    <td>Logo</td>
</tr>
<?php /**PATH C:\wamp64\www\avology\script\resources\views/vendor/mail/html/custom_email_header.blade.php ENDPATH**/ ?>