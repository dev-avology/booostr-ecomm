 <a href="#" data-toggle="modal" data-target=".media-single" class="text-dark single-modal media_checkbox">
    <label for="category-image" class="custom-label text-center">
        <div>
            <img  height="100px" class="<?php echo e($preview_class); ?>" src="<?php echo e(asset($preview)); ?>" alt="">
        </div>
        <span class="text-success">Upload </span> or a select image
    </label>
 </a>   
<div class="image-previewer-pane multi_images_preview_area">
     <?php $__currentLoopData = $value ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
     <div class="img-wrap gallery_image_area ml-1 mt-1 gallery<?php echo e($key); ?>">
            <a href="javascript:void(0)" class="image_close" data-id="<?php echo e($key); ?>"><span class="close " >&times;</span></a>
            <img alt="<?php echo e($media); ?>" height="100" src="<?php echo e(asset($media)); ?>">
            <input type="hidden" value="<?php echo e($media); ?>" name="multi_images[]">
          </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
<?php /**PATH C:\wamp64\www\avology\script\resources\views/components/media/multimediasection1.blade.php ENDPATH**/ ?>