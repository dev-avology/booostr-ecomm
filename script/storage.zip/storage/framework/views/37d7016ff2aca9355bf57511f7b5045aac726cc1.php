<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/dropzone/dropzone.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Edit Product Image','prev'=> url('seller/product')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('product_content'); ?>
<div class="tab-pane fade show active" id="general_info" role="tabpanel" aria-labelledby="home-tab4">
  <form class="ajaxform" action="<?php echo e(route('seller.product.update',$info->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>
     <div class="from-group row mb-2">
        <label for="" class="col-lg-12"><?php echo e(__('Name :')); ?> </label>
        <div class="col-lg-12">
            <input type="text" readonly name="name" required="" class="form-control" placeholder="Enter Product Name" value="<?php echo e($info->title); ?>">
        </div>
     </div>
     <div class="from-group row mb-2">
        <label for="" class="col-lg-12"><?php echo e(__('Featured Image')); ?> : </label>
        <div class="col-lg-12">
          <?php echo e(mediasection(['preview'=>$info->media->value ?? '','value'=>$info->media->value ?? ''])); ?>

      </div>
     </div>
     <div class="from-group row mb-2">
        <label for="" class="col-lg-12"><?php echo e(__('Gallery Images')); ?> : </label>
        <div class="col-lg-12">
          <?php echo e(mediasectionmulti(['value'=>$medias])); ?>

        </div>
     </div>
    <input type="hidden" name="type" value="images">
    <div class="from-group  mb-2">
        <button class="btn btn-primary basicbtn col-lg-2" type="submit"><i class="far fa-save"></i> <?php echo e(__('Update')); ?></button>
    </div>
</form>
</div>
<?php echo e(mediasingle()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin/plugins/dropzone/dropzone.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/jquery-ui.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.product.productmain',['product_id'=>$id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/product/image.blade.php ENDPATH**/ ?>