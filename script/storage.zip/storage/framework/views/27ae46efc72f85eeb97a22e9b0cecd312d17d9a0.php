<?php if(!empty($menus)): ?>
	<?php
	$mainMenus=$menus['data'] ?? [];
	
	?>
	<?php $__currentLoopData = $mainMenus ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<li class="nav-item">
		<?php if(isset($row->children)): ?>
		
		<a class="page-scroll dd-menu collapsed" href="javascript:void(0)" data-bs-toggle="collapse" data-bs-target="#submenu-1-5" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<?php echo e($row->text); ?>  <b class="span-dot"><span class="span-circle"></span></b>
			<div class="drop-icon"><i class="icofont-simple-down"></i></div>
		</a>
		<ul class="sub-menu collapse" id="submenu-1-5">
			<?php $__currentLoopData = $row->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childrens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<!-- <li class="nav-item"><a href="dashboard.html">dashboard</a></li> -->
			<?php echo $__env->make('theme.resto.components.menu.child', ['childrens' => $childrens], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>

		<?php else: ?>
		<a <?php if(url()->current() == url($row->href)): ?> class="active" <?php endif; ?> href="<?php echo e(url($row->href)); ?>" <?php if(!empty($row->target)): ?> target="<?php echo e($row->target); ?>" <?php endif; ?>><?php echo e($row->text); ?> 
			<?php if(url()->current() == url($row->href)): ?>
			  <b class="span-dot"><span class="span-circle"></span></b>
			<?php endif; ?>
		</a>
		<?php endif; ?>
	</li>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/resto/components/menu/parent.blade.php ENDPATH**/ ?>