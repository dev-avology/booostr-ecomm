

<?php $__env->startPush('css'); ?>
<!-- CSS Libraries -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/dropzone/dropzone.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Create Brand','prev'=> url('seller/brand')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.storenotification','data' => []]); ?>
<?php $component->withName('storenotification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<section class="section">
   <div class="row">
      <div class="col-lg-12">
         <form class="ajaxform_with_reset" method="post" action="<?php echo e(route('seller.category.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
               
               <div class="col-lg-5">
                  <strong><?php echo e(__('Image')); ?></strong>
                  <p><?php echo e(__('Upload brand image here')); ?></p>
               </div>
               
               
               <div class="col-lg-7">
                  <div class="card">
                     <div class="card-body">
                        <?php echo e(mediasection()); ?>

                     </div>
                  </div>
               </div>
               
            </div>
            <div class="row">
               
                  <div class="col-lg-5">
                     <strong><?php echo e(__('Description')); ?></strong>
                     <p><?php echo e(__('Add your brand details and necessary information from here')); ?></p>
                  </div>
                  
                  
                  <div class="col-lg-7">
                     <div class="card">
                        <div class="card-body">
                           <div class="from-group row mb-2">
                                 <label for="" class="col-lg-12"><?php echo e(__('Name :')); ?> </label>
                                 <div class="col-lg-12">
                                       <input type="text" name="name" class="form-control" placeholder="Enter Brand Name">
                                 </div>
                              </div>
                              <div class="from-group row mb-2">
                                 <label for="" class="col-lg-12"><?php echo e(__('Description :')); ?> </label>
                                 <div class="col-lg-12">
                                       <textarea  name="description" class="form-control h-150"></textarea>
                                 </div>
                              </div>
                              <div class="from-group row mb-2">
                           <label for="" class="col-lg-12"><?php echo e(__('Is Featured ?')); ?> : </label>
                           <div class="col-lg-12">
                              <select name="featured"  class="form-control">
                                 <option value="1"><?php echo e(__('Yes')); ?></option>
                                 <option value="0"><?php echo e(__('No')); ?></option>
                              </select>
                           </div>
                        </div>
                        <input type="hidden" name="type" value="brand">
                        <div class="row">
                           <div class="col-lg-12">
                                 <button class="btn btn-primary basicbtn" type="submit"><?php echo e(__('Save')); ?></button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>
      </div>
   </div>
</section>
<?php echo e(mediasingle()); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
 <!-- JS Libraies -->
<script src="<?php echo e(asset('admin/plugins/dropzone/dropzone.min.js')); ?>"></script>
<!-- Page Specific JS File -->
<script src="<?php echo e(asset('admin/plugins/dropzone/components-multiple-upload.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/brand/create.blade.php ENDPATH**/ ?>