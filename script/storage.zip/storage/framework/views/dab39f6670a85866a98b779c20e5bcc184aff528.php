

<?php $__env->startSection('title','Coupons'); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Coupons','button_name'=> 'Create New','button_link'=> url('seller/coupon/create')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="Search"><?php echo e(__('Search')); ?></label>
                        <form method="get">
                            <div class="row">
                                <input name="src" type="text" value="<?php echo e($request->src ?? ''); ?>" class="form-control col-lg-4 ml-2" placeholder="search with coupon code...">
                            </div>
                        </form>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover text-center table-borderless">
                            <thead>
                                <tr>
                                     
                                    <th><?php echo e(__('Code')); ?></th>
                                    <th><?php echo e(__('Amount')); ?></th>
                                    <th><?php echo e(__('Start From')); ?></th>
                                    <th><?php echo e(__('Will Expire')); ?></th>
                                    <th><?php echo e(__('Total Used')); ?></th>
                                    <th><?php echo e(__('Coupon For')); ?></th>
                                    <th><?php echo e(__('Coupon For id')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e($row->code); ?></td>
                                    <td><?php echo e($row->value); ?></td>
                                    <td><?php echo e($row->start_from); ?></td>
                                    <td><?php echo e($row->will_expire); ?></td>
                                    <td>change it here</td>
                                    <td><?php echo e($row->coupon_for_name); ?></td>
                                    <td><?php echo e($row->coupon_for_id); ?></td>
                                    <td><span class="badge badge-<?php echo e($row->status == 1 ? 'success' : 'warning'); ?>"><?php echo e($row->status == 1 ? 'Active' : 'Disable'); ?></span></td>
                                    <td class="">
                                        <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <?php echo e(__('Action')); ?>

                                        </button>
                                        <div class="dropdown-menu" x-placement="bottom-start">
                                        
                                            <a class="dropdown-item has-icon text-warning" href="<?php echo e(route('seller.coupon.edit', $row->id)); ?>"><i class="fa fa-edit"></i><?php echo e(__('Edit')); ?></a>


                                            <a class="dropdown-item has-icon delete-confirm text-danger" href="javascript:void(0)" data-id="<?php echo e($row->id); ?>"><i class="fa fa-trash"></i><?php echo e(__('Delete')); ?></a>
                                            <!-- Delete Form -->
                                            <form class="d-none" id="delete_form_<?php echo e($row->id); ?>" action="<?php echo e(route('seller.coupon.destroy', $row->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        </form>
                                        </div>
                                    </td>
                                </tr>      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                     <?php echo e($posts->links('vendor.pagination.bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/coupon/index.blade.php ENDPATH**/ ?>