

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h4><?php echo e(__('User Info')); ?></h4>
    </div>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Name:')); ?> <b><?php echo e($user->name); ?></b>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Email:')); ?> <b><?php echo e($user->email); ?></b>
                            </li>
                               <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Phone:')); ?> <b><?php echo e($user->phone); ?></b>
                            </li>
                          
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Registration Date:')); ?> <b><?php echo e($user->created_at->isoFormat('LL')); ?></b>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Total Orders')); ?>

                                <span class="badge badge-info badge-pill"><?php echo e($user->user_orders->count()); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Total Processing Orders')); ?>

                                <span class="badge badge-warning badge-pill"><?php echo e($pending_orders); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Total Complete Orders')); ?>

                                <span class="badge badge-success badge-pill"><?php echo e($completed_orders); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e(__('Total Cancalled Orders')); ?>

                                <span class="badge badge-danger badge-pill"><?php echo e($cancalled_orders); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e(__('Order History')); ?></h4>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive table-invoice">
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <th><?php echo e(__('Invoice ID')); ?></th>
                                        <th><?php echo e(__('Amount')); ?></th>
                                        <th><?php echo e(__('Order Type')); ?></th>
                                        <th><?php echo e(__('Payment Status')); ?></th>
                                        <th><?php echo e(__('Order Status')); ?></th>
                                        <th><?php echo e(__('Action')); ?></th>
                                    </tr>
                                    <?php $__currentLoopData = $user->user_orders()->paginate(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><a href="<?php echo e(route('seller.order.show',$value->id)); ?>"><?php echo e($value->invoice_no); ?></a></td>
                                        <td class="font-weight-600"><?php echo e(get_option('currency_data',true)->currency_icon); ?><?php echo e($value->total); ?></td>
                                        <td>
                                            <?php echo e($value->order_method); ?>

                                        </td>
                                        <td>
                                            <?php if($value->payment_status == 1): ?>
                                            <span class="badge badge-primary"><?php echo e(__('Active')); ?></span>
                                            <?php else: ?> 
                                            <span class="badge badge-danger"><?php echo e(__('Incompleted')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($value->status_id == 1): ?>
                                                <span class="badge badge-primary"><?php echo e(__('Complete')); ?></span>
                                            <?php elseif($value->status_id == 2): ?>
                                                <span class="badge badge-warning"><?php echo e(__('Cancelled')); ?></span>
                                            <?php elseif($value->status_id == 3): ?>
                                                <span class="badge badge-danger"><?php echo e(__('Pending')); ?></span> 
                                            <?php else: ?> 
                                                <span class="badge badge-info"><?php echo e($value->orderstatus->name); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('seller.order.show',$value->id)); ?>" class="btn btn-primary"><i class="fas fa-eye"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="float-right">
                            <?php echo e($user->user_orders()->paginate(20)->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/user/profile.blade.php ENDPATH**/ ?>