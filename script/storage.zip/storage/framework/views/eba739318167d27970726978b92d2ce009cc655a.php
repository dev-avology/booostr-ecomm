

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="section">
    <div class="section-header row">
        <div class="col-sm-12">
            <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link  <?php echo e($request_status == null ? 'active' : ''); ?> " href="<?php echo e(route('seller.order.index')); ?>">All</a>
                </li>
                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                <a class="nav-link  <?php echo e($request_status == $row->id ? 'active' : ''); ?>" href="<?php echo e(url('seller/order?status='.$row->id)); ?>"><?php echo e($row->name); ?> <span class="badge badge-secondary"><?php echo e($row->orderstatus_count); ?></span></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</section>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.storenotification','data' => []]); ?>
<?php $component->withName('storenotification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

 <div class="card">
    <div class="card-header">
        <h4><?php echo e(__('Orders')); ?></h4>
        <form class="card-header-form">
            <div class="input-group">
                <input type="text" name="src" value="<?php echo e($request->src ?? ''); ?>" class="form-control" required=""  placeholder="Order Id" />
                <div class="input-group-btn">
                    <button type="submit" class="btn btn-primary btn-icon"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </form>
        <button class="btn btn-sm btn-primary  ml-1" type="button" data-toggle="modal" data-target="#searchmodal">
            <i class="fe fe-sliders mr-1"></i> <?php echo e(__('Filter')); ?> <span class="badge badge-primary ml-1 d-none">0</span>
        </button>
    </div>
    <div class="card-body">
        <form method="post" action="<?php echo e(route('seller.order.multipledelete')); ?>" class="ajaxform_with_reload">
            <?php echo csrf_field(); ?>
            <div class="float-left">
                <?php if(count($orders) > 0): ?>
                <div class="input-group mb-1">
                    <select class="form-control selectric" name="method">
                        <option disabled selected=""><?php echo e(__('Select Fulfillment')); ?></option>
                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                        <option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
                    
                    </select>
                    <div class="input-group-append">                                            
                        <button class="btn btn-primary basicbtn" type="submit"><?php echo e(__('Submit')); ?></button>
                    </div>
                </div>
                <?php endif; ?>
            </div>  
            <div class="float-right">
                <?php if(count($request->all()) > 0): ?>
                <?php echo e($orders->appends($request->all())->links('vendor.pagination.bootstrap-4')); ?>

                <?php else: ?>
                <?php echo e($orders->links('vendor.pagination.bootstrap-4')); ?>

                <?php endif; ?>
            </div>
            <div class="table-responsive">
                <table class="table table-hover table-nowrap card-table text-center">
                    <thead>
                        <tr>
                            <th class="text-left" ><div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input checkAll" id="selectAll">
                            <label class="custom-control-label checkAll" for="selectAll"></label>
                            </div></th>
                            <th class="text-left" ><?php echo e(__('Order')); ?></th>
                            <th ><?php echo e(__('Date')); ?></th>
                            <th><?php echo e(__('Customer')); ?></th>
                            <th class="text-right"><?php echo e(__('total')); ?></th>
                            <th><?php echo e(__('Payment')); ?></th>
                            <th><?php echo e(__('Fulfillment')); ?></th>
                            <th class="text-right"><?php echo e(__('Type')); ?></th>
                            <th class="text-right"><?php echo e(__('Item(s)')); ?></th>
                            <th class="text-right"><?php echo e(__('Print')); ?></th>
                        </tr>
                    </thead>
                    <tbody class="list font-size-base rowlink" data-link="row">
                        <?php $__currentLoopData = $orders ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                               $p_types = $product_type->pluck('id')->flatten()->toArray();
                            // $orderItems = $row->orderitems->map(function ($term) use ($product_typeIds) {
                            //     dump($term->termcategories());
                            //     return $term->termcategories()?->filter(function ($cat) use ($product_typeIds) {
                            //         return in_array($cat->id, $product_typeIds);
                            //     });
                            // });

                            $selected_product_type = [];

                           foreach($row->orderitems ?? [] as $row1){
                             foreach ($row1->term->termcategories as $key => $value) {
                                   if(in_array($value->category_id,$p_types))
                                     array_push($selected_product_type, $value->category_id);
                             }
                           }
                           
                         // dump($selected_product_type);
                         $order_type = 'Goods'; 
                          if(count($selected_product_type) == 1){
                               if(!in_array(52,$selected_product_type)){
                                $order_type = 'Digital '; 
                               }
                          }elseif(count($selected_product_type) > 1){
                                $order_type = 'Mixed'; 
                          }

                        $ordermeta=json_decode($row->ordermeta->value ?? ''); 
                    ?>
                        <tr>
                            <td  class="text-left">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($row->id); ?>" value="<?php echo e($row->id); ?>">
                                    <label class="custom-control-label" for="customCheck<?php echo e($row->id); ?>"></label>
                                </div>
                            </td>
                            <td class="text-left">
                                <a href="<?php echo e(route('seller.order.show',$row->id)); ?>"><?php echo e($row->invoice_no); ?></a>
                            </td>
                            <td><a href="<?php echo e(route('seller.order.show',$row->id)); ?>"><?php echo e($row->created_at->format('d-F-Y')); ?></a></td>
                            <td><?php if($row->user_id !== null): ?><a href="<?php echo e(route('seller.user.show',$row->user_id)); ?>"><?php echo e(($ordermeta != '' ) ? $ordermeta->name : $row->user->name); ?></a> <?php else: ?> <?php echo e(__('Guest User')); ?> <?php endif; ?></td>
                            <td ><?php echo e(currency_formate($row->total)); ?></td>
                            <td>
                                <?php if($row->payment_status==2): ?>
                                <span class="badge badge-warning"><?php echo e(__('Pending')); ?></span>
                                <?php elseif($row->payment_status==1): ?>
                                <span class="badge badge-success"><?php echo e(__('Complete')); ?></span>
                                <?php elseif($row->payment_status==0): ?>
                                <span class="badge badge-danger"><?php echo e(__('Cancel')); ?></span> 
                                <?php elseif($row->payment_status==3): ?>
                                <span class="badge badge-danger"><?php echo e(__('Incomplete')); ?></span> 
                                <?php elseif($row->payment_status==4): ?>
    							<span class="badge badge-danger"><?php echo e(__('Authorized')); ?></span>
                                <?php elseif($row->payment_status==5): ?>
                                <span class="badge badge-warning"><?php echo e(__('Refunded')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($row->orderstatus == null ? 'badge-warning' :''); ?> text-white" style="background-color: <?php echo e($row->orderstatus->slug); ?>"><?php echo e($row->orderstatus->name ?? ''); ?></span>
                            </td>
                            
                            <td> <?php echo e($order_type); ?> </td>
                            <td><?php echo e($row->orderitems_count); ?></td>
                            <td>
                                <a target="_blank" href="<?php echo e(route('seller.order.print',$row->id)); ?>" class="btn btn-primary">Print</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                   
                </table>
            </div>
        </form>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="searchmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="card-header-title"><?php echo e(__('Filters')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form>
            <div class="modal-body">
                <div class="form-group row mb-4">
                    <label class="col-sm-7"><?php echo e(__('Payment Status')); ?></label>
                    <div class="col-sm-5">
                        <select class="form-control selectric" name="payment_status" id="payment_status">
                            <option value="2"><?php echo e(__('Pending')); ?></option>
                            <option value="1" ><?php echo e(__('Complete')); ?></option>
                            <option value="3" ><?php echo e(__('Incomplete')); ?></option>
                            <option value="0" ><?php echo e(__('Cancel')); ?></option>
                           
                        </select>
                    </div>
                </div>
                <hr />
                <div class="form-group row mb-4">
                    <label class="col-sm-7"><?php echo e(__('Fulfillment status')); ?></label>
                    <div class="col-sm-5">
                        <select class="form-control selectric" name="status" id="status" >
                          <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->id); ?>" <?php echo e($request_status == $row->id ? 'selected' : ''); ?>><?php echo e($row->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <hr />
                <div class="form-group row mb-4">
                    <label class="col-sm-3"><?php echo e(__('Starting date')); ?></label>
                    <div class="col-sm-9">
                        <input type="date" name="start" class="form-control" value="<?php echo e($request->start); ?>" />
                    </div>
                </div>
                <hr />
                <div class="form-group row mb-4">
                    <label class="col-sm-3"><?php echo e(__('Ending date')); ?></label>
                    <div class="col-sm-9">
                        <input type="date" name="end" class="form-control" value="<?php echo e($request->end); ?>" />
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="<?php echo e(route('seller.order.index')); ?>" class="btn btn-secondary"><?php echo e(__('Clear Filter')); ?></a>
                <button type="submit" class="btn btn-primary"><?php echo e(__('Filter')); ?></button>
            </div>
            </form>
        </div>
    </div>
</div>
<input type="hidden" id="payment" value="<?php echo e($request->payment_status ?? ''); ?>">
<input type="hidden" id="order_status" value="<?php echo e($request->status ?? ''); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/order_index.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/order/index.blade.php ENDPATH**/ ?>