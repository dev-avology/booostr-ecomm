
<?php $__env->startSection('content'); ?>
<!-- Start Breadcrumbs Area -->
		<div class="breadcrumbs" style="background-image:url(<?php echo e(asset($page_data->cart_page_banner ?? '')); ?>)">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-8 col-12">
						<div class="breadcrumbs-content">
							<h1 class="page-title"><?php echo e($page_data->cart_page_title ?? 'Cart'); ?></h1>
							<p><?php echo e($page_data->cart_page_description ?? 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text'); ?></p>
						</div>
						<ul class="breadcrumb-nav">
							<li><a href="<?php echo e(url('/')); ?>"><i class="icofont-home"></i> <?php echo e(__('Home')); ?></a></li>
							<li><i class="icofont-cart"></i> <?php echo e($page_data->cart_page_title ?? 'Cart'); ?></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Breadcrumbs Area -->
		
		
		<!-- Shopping Cart -->
		<div class="shopping-cart section">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<!-- Shopping Summery -->
						<table class="table shopping-summery">
							<thead>
								<tr class="main-hading">
									<th><i class="icofont-price"></i> <?php echo e(__('PRODUCT')); ?></th>
									<th><i class="icofont-pencil-alt-5"></i> <?php echo e(__('NAME')); ?></th>
									<th class="text-center"><i class="icofont-money"></i> <?php echo e(__('UNIT PRICE')); ?></th>
									<th class="text-center"><i class="icofont-attachment"></i> <?php echo e(__('QUANTITY')); ?></th>
									<th class="text-center"><i class="icofont-price"></i> <?php echo e(__('TOTAL')); ?></th> 
									<th class="text-center"><i class="icofont-trash"></i><?php echo e(__('Remove')); ?></th>
								</tr>
							</thead>
							<tbody class="cart_page">
								
								
							</tbody>
						</table>
						<!--/ End Shopping Summery -->
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<!-- Total Amount -->
						<div class="total-amount">
							<div class="row">
								<div class="col-lg-8 col-md-5 col-12">
									<div class="left">
										<div class="coupon">
											<form method="post" action="<?php echo e(route('makediscount')); ?>" class="ajaxform_with_reload">
												<?php echo csrf_field(); ?>
												<input name="coupon" required="" placeholder="Enter Your Coupon">
												<button class="btn basicbtn" type="submit"><?php echo e(__('Apply')); ?></button>
											</form>
										</div>
										
									</div>
								</div>
								<div class="col-lg-4 col-md-7 col-12">
									<div class="right">
										<ul>
											<li><?php echo e(__('Cart Subtotal')); ?><span class="cart_subtotal"><?php echo e(Cart::instance('default')->subtotal()); ?></span></li>
											<li><?php echo e(__('Tax')); ?><span><?php echo e(Cart::instance('default')->tax()); ?></span></li>
											<li><?php echo e(__('You Save')); ?><span><?php echo e(Cart::instance('default')->discount()); ?></span></li>
											<li class="last"><?php echo e(__('Total')); ?><span class="cart_total"><?php echo e(Cart::instance('default')->total()); ?></span></li>
										</ul>
										<div class="button">
											<a href="<?php echo e(url('/checkout')); ?>" class="btn"><i class="icofont-shopping-cart"></i> <?php echo e(__('Checkout')); ?></a>
											<a href="<?php echo e(url('/products')); ?>" class="btn primary"><i class="icofont-plus-circle"></i> <?php echo e(__('Continue shopping3')); ?></a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!--/ End Total Amount -->
					</div>
				</div>
			</div>
		</div>
		<!--/ End Shopping Cart -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.resto.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/resto/cart.blade.php ENDPATH**/ ?>