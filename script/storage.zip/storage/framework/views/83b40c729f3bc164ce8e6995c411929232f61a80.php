
<?php $__env->startSection('content'); ?>

<!-- Breadcrumbs -->
<section class="breadcrumbs">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="bread-inner  gr-overlay" style="background-image:url(<?php echo e(asset($products_page_banner)); ?>)">
					<div class="row">
						<!-- Breadcrumb-Content -->
						<div class="col-lg-6 col-md-8 col-12">
							<div class="breadcrumb-content">
								<h2><?php echo e($page_title); ?></h2>
								<p><?php echo e($products_page_description); ?></p>
								<ul class="breadcrumb-nav">
									<li><a href="<?php echo e(url('/')); ?>"><i class="icofont-home"></i> <?php echo e(__('Home')); ?></a></li>
									<li><i class="icofont-fast-food"></i> <?php echo e($page_title); ?></li>
								</ul>
							</div>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End Breadcrumbs -->

<!-- Product Style -->
<section class="product-area shop-sidebar shop p-top-40 p-btm-70">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-4 col-12 col-side">
				<div class="shop-sidebar shop-sidebar-inner m-top-30">
					<div class="cat-open-close"><a><i class="icofont-close"></i></a></div>
					<div class="shop-sidebar-active">
						<!-- Single Widget -->
						<div class="single-widget category category_area">
							<h3 class="title"><?php echo e(__('Shop By Category')); ?></h3>
							<ul class="categor-list product_category">
								
								
							</ul>
						</div>
						<div class="single-widget category brand_area">
							<h3 class="title"><?php echo e(__('Shop By Brand')); ?></h3>
							<ul class="categor-list product_brands">
								
								
							</ul>
						</div>

						
						<!--/ End Single Widget -->
						<!-- Shop By Price -->
						<div class="single-widget range">
							<h3 class="title"><?php echo e(__('Shop by Price')); ?></h3>
							<div class="price-filter">
								<div class="price-filter-inner">
									<div id="slider-range" data-max="" data-min=""></div>
									<div class="price_slider_amount">
										<div class="label-input">
											<input type="text" id="amount" name="price" placeholder="Add Your Price"/>
											<span><button id="product_price_filter" type="button" class="pc-btn theme-btn prodcut-btn"><?php echo e(__('Filter')); ?></button></span>
											
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="filter_widget_area mt-4">
							
						</div>
						<!--/ End Shop By Price -->
						
					</div>
				</div>
			</div>
			<div class="col-lg-9 col-md-8 col-12 col-main">
				<div class="category-grid-list">
					<div class="row">
						
						<div class="col-12">
							<div class="category-grid-topbar">
								<h3 class="title"><?php echo e(__('Showing')); ?> <span class="from_products">0</span>- <span class="to_products">-</span> <?php echo e(__('of')); ?> <span class="total_products"></span> <?php echo e(__('Products found')); ?></h3>
								<!-- Shop Top -->
								<div class="shop-top">
									<div class="shop-shorter">
										<div class="single-shorter">
											<label><?php echo e(__('Show :')); ?></label>
											<select id="product_limit">
												<option value="12" selected="selected"><?php echo e(__('12')); ?></option>
												<option value="25"><?php echo e(__('25')); ?></option>
												<option value="35"><?php echo e(__('35')); ?></option>
												<option value="45"><?php echo e(__('45')); ?></option>
											</select>
										</div>
										<div class="single-shorter">
											<label><?php echo e(__('Sort By :')); ?></label>
											<select id="order_by">
												<option value="DESC"><?php echo e(__('Short By latest')); ?></option>
												<option value="ASC"><?php echo e(__('Default Shorting')); ?></option>
												<option value="rating"><?php echo e(__('Short By Reviews')); ?></option>
											</select>
										</div>
									</div>
								</div>
								<!--/ End Shop Top -->
								<div class="shop-navigation-menu">
									<div class="filter-menu"><i class="icofont-filter"></i><span>Filter</span></div>
									<nav>
										<div class="nav nav-tabs" id="nav-tab" role="tablist">
											<button class="nav-link active" id="nav-grid-tab" data-bs-toggle="tab" data-bs-target="#nav-grid" type="button" role="tab" aria-controls="nav-grid" aria-selected="true" > <i class="icofont-calendar"></i></button>
											<button class="nav-link" id="nav-list-tab" data-bs-toggle="tab" data-bs-target="#nav-list" type="button" role="tab" aria-controls="nav-list" aria-selected="false"><i class="icofont-listing-box"></i></button>
										</div>
									</nav>
								</div>
							</div>
							<div class="tab-content" id="nav-tabContent">
								<div class="tab-pane fade show active" id="nav-grid" role="tabpanel" aria-labelledby="nav-grid-tab">
									<div class="row primary_products_area">
										<h6 class="text-center mt-2 none zero_product"><?php echo e(__('0 Product available')); ?></h6>
										
									</div>
								</div>
								<div class="tab-pane fade" id="nav-list" role="tabpanel" aria-labelledby="nav-list-tab">
									<div class="row ">
										<div class="col-12 grid_products_area">
											<h6 class="text-center mt-2 none zero_product"><?php echo e(__('0 Product available')); ?></h6>
											
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<!-- Pagination -->
									<div class="pagination left">
										<ul class="pagination-list">
											
										</ul>
									</div>
									<!--/ End Pagination -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
 <?php echo $__env->make('theme.grshop.components.quickview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/ End Product Style 1  -->	
<input type="hidden" id="cat" value="<?php echo e($categoryid ?? ''); ?>">
<input type="hidden" id="term_src" value="<?php echo e($request->src ?? ''); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('theme/jquery.unveil.js')); ?>"></script>
<script src="<?php echo e(asset('theme/grshop/js/products.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.grshop.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/products.blade.php ENDPATH**/ ?>