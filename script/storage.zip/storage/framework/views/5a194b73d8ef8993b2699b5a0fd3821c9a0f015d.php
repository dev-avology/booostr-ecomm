
<?php $__env->startSection('content'); ?>
<!-- Start Breadcrumbs Area -->
		<div class="breadcrumbs" >
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-12">
						<div class="breadcrumbs-content">
						    <?php
							 $club_info = tenant_club_info();
							?>
							<h1 class="page-title"><?php echo e($club_info['club_name']); ?> Store</h1>    
							<p><?php echo e($info->title); ?></p>
							<p><?php echo e($meta->page_excerpt ?? ''); ?></p>
						</div>
						
					</div>
				</div>
			</div>
		</div>
		<!--/ End Breadcrumbs Area -->
		
		
		<!-- Shopping Cart -->
		<div class="shopping-cart section" id="cart-anchor-clr">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<?php 
						   $club_info = tenant_club_info();
                           $content = $meta->page_content ?? '';
						   $lastupdated = Carbon\Carbon::parse(tenant('created_at'))->format('d-m-Y');
						   if(isset($club_info['club_url'])){
							$club_url = $club_info['club_url'];
							$club_url = '<a href="'.$club_url.'" target="_blank">'.$club_url.'</a>';
						   }else{
							$club_url = 'https://staging3.booostr.co/all-booster-clubs/';
							$club_url = '<a href="'.$club_url.'" target="_blank">'.$club_url.'</a>';
						   }
						   $address = explode(',',$club_info['address']);
                           $store_country = trim($address[count($address)-1]);

                           $club_email = '<a href="mailto:'.$club_info['club_email'].'">'.$club_info['club_email'].'</a>';


						   $content = str_replace('[Date]',$lastupdated,$content);
						   $content = str_replace(array('[store_name]','[club_name]'),$club_info['club_name'].' Store',$content);
						   $content = str_replace(array('[store_url]','[club_profile_url]'),$club_url,$content);
						   $content = str_replace(array('[store_email]','[club_email]'),$club_email,$content);
						   $content = str_replace('[store_jurisdiction]',$store_country,$content);
						   $content = str_replace('[club_manager_first_and_last_name]',$club_info['co_profile_manager']??'',$content);
						   $content = str_replace('[club_address]',$club_info['address'],$content);
						   
                         ?>
						<?php echo $content; ?>

					</div>
				</div>
			</div>
		</div>
		<!--/ End Shopping Cart -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/store/checkout/page.blade.php ENDPATH**/ ?>