<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        table,
        th,
        td {
            border-collapse: collapse;
        }

        p,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            padding: 0;
            margin: 0;
        }

        .border-style:after {
            position: absolute;
            content: '';
            border-bottom: 1px solid #e5e5e5;
            width: 94%;
            transform: translateX(-50%);
            left: 50%;
        }

        .border-style {
            position: relative;
        }

        .spac-btm {
            padding-bottom: 30px;
        }

        .spac-top {
            padding-top: 30px;
        }

        tr.br-none:after {
            border: 0;
        }

        .add-shipping-color p {
            color: #3c3c3c;
        }

        .add-shipping-color a {
            color: #3c3c3c;
            text-decoration: none;
        }

        #click_to_login {
            text-decoration: underline !important;
        }

        #learn_more {
            color: #fff;
            text-decoration: underline !important;
        }
    </style>
</head>


<body style="background-color: #f4f6f9;">
    <div class="table-wrapper" style="width: 100%;max-width: 700px;margin: 0 auto;border-radius: 20px;overflow: hidden;">

        <table style="width: 100%;max-width: 700px; margin: 0 auto; background-color: #fff;border-collapse: collapse;">
            <tbody>

                <tr style="background-color: #535353; width: 100%;" class="border-style br-none">
                    <th style="width:15%;text-align:left;padding: 18px 0 7px 20px;border-collapse:collapse;">

                        
                    <img src="<?php echo e(env('WP_URL')); ?><?php echo e(tenant()->logo); ?>" alt="logo"
                                style="width: 100%;max-width: 120px;"/>
                        
                    </th>
                    <th style="width: 70%;border-collapse: collapse;">
                        <h2
                            style="font-family: 'Nunito', 'Segoe UI', Arial; font-size: 24px; font-weight: normal; text-align: left; text-transform: capitalize; color: #fff; padding-left: 50px;">
                            <?php echo e($invoice_info->store_legal_name ?? ''); ?> Store
                        </h2>
                    </th>
                    <th style="width: 15%; padding-right: 20px; text-align: right;border-collapse: collapse;">
                        <a href=""
                            style="color: #fff; font-size: 20px; font-weight: 100; text-transform: uppercase; text-decoration: none; font-family: 'Nunito', 'Segoe UI', Arial;">login</a>
                    </th>
                </tr>
            </tbody>
        </table>

        <table style="width: 100%;max-width: 700px; margin: 0 auto; background-color: #fff;">
            <tbody>
                <tr class="border-style">
                    <td style="width: 100%; padding-left: 15px;font-size: 15px; padding-right: 15px;"
                        class="spac-top spac-btm">
                            <p
                                style="padding-left: 20px;margin: 0; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c;font-weight: 500;">
                                Hi sam, this recipt is related to order which you have created please check all details in below. 
                            </p>
                    </td>
                </tr>
            </tbody>
        </table>


        


       
        <table style="width: 100%; max-width: 700px; margin: 0 auto; background-color: #fff;">
            <tr class="border-style">
                <td style="width: 50%; padding-left: 15px; font-size: 15px; text-align: left;"
                    class="spac-top spac-btm">
                    <span
                        style="font-weight: bold; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; margin: 0; padding-left: 20px;">
                        Order #: <span style="font-weight: 500;">00001</span>
                    </span><br>
                    <span
                        style="font-weight: bold; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; margin: 0; padding-left: 20px">Date
                        Placed:<span style="font-weight: 500;">
                            10/12/2000</span>
                    </span>
                </td>
                <td style="width: 50%; padding-left: 15px; font-size: 15px; text-align: left;"
                    class="spac-top spac-btm">
                    <a id="click_to_login" href="https://staging3.booostr.co/dashboard/?ua=user-receipts"
                        style="font-size: 15px; color: #00c0ffba; font-weight: 700; font-family: 'Nunito', 'Segoe UI', Arial; text-decoration: none;">Click
                        to Login and View Order</a>
                </td>
            </tr>
        </table> 

        <table style="width: 100%; max-width: 700px; margin: 0 auto; background-color: #fff;">
            <tbody>
                <tr class="border-style">
                    <td style="width: 50%; padding-left: 15px; font-size: 15px; padding-right: 15px;"
                        class="spac-top spac-btm">
                        <h5
                            style="padding-left: 20px; font-weight: bold; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; font-size: 16px;">
                            Billing Address:
                        </h5>
                        <p class="add-shipping-color"
                            style="padding-left: 20px; font-weight: 500; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; font-size: 16px;">
                            <?php
                                $ordermeta=json_decode($info->ordermeta ?? '');
                                $billing_address=json_decode($ordermeta->value ?? '');
                         
                                $billing_name = $billing_address->name;
                                $billing_email = $billing_address->email;
                                $billing_phone = $billing_address->phone;

                                $billing_add = $billing_address->billing->address;
                                $billing_city = $billing_address->billing->city;
                                $billing_state = $billing_address->billing->state; 
                                $billing_country = $billing_address->billing->country;
                                $billing_post_code = $billing_address->billing->post_code;

                                $new_billing_address = $billing_name . '<br>' . $billing_add . '<br>' . $billing_city . ', ' . $billing_state . ' ' . $billing_post_code . '<br>' . $billing_country . '<br>' . $billing_phone . '<br>' . $billing_email;
                            ?>
                            
                            <?php echo $new_billing_address ?? '' ?>
                        </p>
                    </td>
                    <td style="width: 50%; padding-left: 15px; font-size: 15px; padding-right: 15px;padding-bottom: 72px;"
                        class="spac-top spac-btm">
                        <h5
                            style="padding-left: 20px; font-weight: bold; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; font-size: 16px;">
                            Payment Information:
                        </h5>
                        
                        <span
                            style="padding-left: 20px; font-weight: 500; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; font-size: 16px; text-transform: capitalize;">Status:
                            <span>Authorized</span>
                        </span>
                        <p
                            style="padding-left: 20px; font-weight: 500; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; font-size: 16px; text-transform: capitalize;">
                            Card: <span>765235476574</span></p>
                        <p
                            style="padding-left: 20px; font-weight: 500; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; font-size: 16px; text-transform: capitalize;">
                            Name: <span>which</span></p>
                        <p
                            style="padding-left: 20px; font-weight: 500; font-family: 'Nunito', 'Segoe UI', Arial; color: #3c3c3c; font-size: 16px; text-transform: capitalize;">
                            Amount: <span>$2000</span></p>
                    </td>
                </tr>
            </tbody>
        </table>

        

        
        

        

        
    </div>
</body>

</html>
<?php /**PATH C:\wamp64\www\avology\script\resources\views/welcome-recipt.blade.php ENDPATH**/ ?>