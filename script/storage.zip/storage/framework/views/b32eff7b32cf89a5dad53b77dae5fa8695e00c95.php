
<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Theme Settings'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/summernote/summernote-bs4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/dropzone/dropzone.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-12 col-sm-12 col-lg-12">
		<div class="card">
			<div class="card-header">
				<h4><?php echo e(__('Theme Settings')); ?></h4>
			</div>
			<div class="card-body">
				<div class="row">
					<div class="col-12 col-sm-12 col-md-4">
						<ul class="nav nav-pills flex-column" id="myTab4" role="tablist">
							<li class="nav-item">
								<a class="nav-link active"  data-toggle="tab" href="#home_page" role="tab" aria-controls="home" aria-selected="true"><?php echo e(__('Home Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#product_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Product Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#cart_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Cart Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#wishlist_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Wishlist Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#checkout_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Checkout Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#menu_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Menu Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#products_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Products Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#blog_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Blogs Page')); ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#settings_page" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Template primary settings')); ?></a>
							</li>

							<li class="nav-item">
								<a class="nav-link"  data-toggle="tab" href="#contact" role="tab" aria-controls="profile" aria-selected="false"><?php echo e(__('Contact Page')); ?></a>
							</li>
							
						</ul>
					</div>
					<div class="col-12 col-sm-12 col-md-8">
						<div class="tab-content no-padding" id="myTab2Content">
							<div class="tab-pane fade show active" id="home_page" role="tabpanel" aria-labelledby="home_page">
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','home_page')); ?>">
									<?php echo csrf_field(); ?>
									<?php
									$home_page_data=get_option('home_page',true);
									$home_page_data=$home_page_data->meta ?? '';
									?>
								<h6><?php echo e(__('Featured product Area')); ?></h6>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" name="option[featured_products_title]" value="<?php echo e($home_page_data->featured_products_title ?? ''); ?>" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Description  :')); ?></label>
									<textarea name="option[featured_products_description]" class="form-control"><?php echo e($home_page_data->featured_products_description ?? ''); ?></textarea>
								</div>
								<?php
								$featured_products_status=$home_page_data->featured_products_status ?? 'yes';
								?>
								<div class="form-group">
									<label><?php echo e(__('Status :')); ?></label>
									<select class="form-control selectric" name="option[featured_products_status]">
										<option value="yes" <?php if($featured_products_status == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enabled')); ?></option>
										<option value="no" <?php if($featured_products_status == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disabled')); ?></option>
									</select>
								</div>

								<hr>
								<h6><?php echo e(__('Products Area')); ?></h6>
								<div class="form-group">
									<label><?php echo e(__('Short Title :')); ?></label>
									<input type="text"  value="<?php echo e($home_page_data->products_area_short_title ?? ''); ?>" name="option[products_area_short_title]" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($home_page_data->products_area_title ?? ''); ?>" name="option[products_area_title]" class="form-control">
								</div>
								
								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[products_area_description]" class="form-control"><?php echo e($home_page_data->products_area_description ?? ''); ?></textarea>
								</div>

								<hr>
								<h6><?php echo e(__('Discount Product Area')); ?></h6>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($home_page_data->discount_product_title ?? ''); ?>" name="option[discount_product_title]" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[discount_product_description]" class="form-control"><?php echo e($home_page_data->discount_product_description ?? ''); ?></textarea>
								</div>
								<?php
								$discount_product_status=$home_page_data->discount_product_status ?? 'yes';
								?>
								<div class="form-group">
									<label><?php echo e(__('Status :')); ?></label>
									<select class="form-control selectric" name="option[discount_product_status]">
										<option value="yes" <?php if($discount_product_status == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enabled')); ?></option>
										<option value="no" <?php if($discount_product_status == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disabled')); ?></option>
									</select>
								</div>

								<hr>
								<h6><?php echo e(__('Testimonial Area')); ?></h6>
								<label><?php echo e(__('Section Background Image :')); ?></label>
								<?php echo e(mediasection([
										'preview_class'=>'testimonial_background',
										'input_id'=>'testimonial_background',
										'input_class'=>'testimonial_background',
										'input_name'=>'option[testimonial_background]',
										'value'=>$home_page_data->testimonial_background ?? '',
										'preview'=>$home_page_data->testimonial_background ?? 'admin/img/img/placeholder.png'
									])); ?>

								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" name="option[testimonial_title]" value="<?php echo e($home_page_data->testimonial_title ?? ''); ?>" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[testimonial_description]" value="<?php echo e($home_page_data->testimonial_description ?? ''); ?>" class="form-control"></textarea>
								</div>
								<?php
								$testimonial_status=$home_page_data->testimonial_status ?? 'yes';
								?>
								<div class="form-group">
									<label><?php echo e(__('Status :')); ?></label>
									<select class="form-control selectric" name="option[testimonial_status]">
										<option value="yes" <?php if($testimonial_status == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enabled')); ?></option>

										<option value="no" <?php if($testimonial_status == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disabled')); ?></option>
									</select>
								</div>

								<hr>
								<h6><?php echo e(__('Menu Area')); ?></h6>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($home_page_data->menu_area_title ?? ''); ?>" name="option[menu_area_title]" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[menu_area_description]" class="form-control"><?php echo e($home_page_data->menu_area_description ?? ''); ?></textarea>
								</div>
								<?php
								$menu_area_status=$home_page_data->menu_area_status ?? 'yes';
								?>
								<div class="form-group">
									<label><?php echo e(__('Status :')); ?></label>
									<select class="form-control selectric" name="option[menu_area_status]">
										<option value="yes" <?php if($menu_area_status == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enabled')); ?></option>

										<option value="no" <?php if($menu_area_status == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disabled')); ?></option>
									</select>
								</div>

								<hr>
								<h6><?php echo e(__('Blog Area')); ?></h6>
								<div class="form-group">
									<label><?php echo e(__('Short Title :')); ?></label>
									<input type="text" value="<?php echo e($home_page_data->blog_area_short_title ?? ''); ?>" name="option[blog_area_short_title]" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?> </label>
									<input type="text" value="<?php echo e($home_page_data->blog_area_title ?? ''); ?>" name="option[blog_area_title]" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Description :')); ?> </label>
									<textarea name="option[blog_area_description]" class="form-control"><?php echo e($home_page_data->blog_area_description ?? ''); ?></textarea>
								</div>
								<?php
								$blog_area_status=$home_page_data->blog_area_status ?? 'yes';
								?>
								<div class="form-group">
									<label><?php echo e(__('Status :')); ?> </label>
									<select class="form-control selectric" name="option[blog_area_status]">
										<option value="yes" <?php if($blog_area_status == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enabled')); ?></option>

										<option value="no" <?php if($blog_area_status == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disabled')); ?></option>
									</select>
								</div>
								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
								</form>
							</div>


							<div class="tab-pane fade" id="product_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$product_page_data=get_option('product_page',true);
								$product_page_data=$product_page_data->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','product_page')); ?>">
									<?php echo csrf_field(); ?>
								<div class="form-group">
									<label><?php echo e(__('Short Title :')); ?></label>
									<input placeholder="Related products" type="text" name="option[product_page_short_title]" value="<?php echo e($product_page_data->product_page_short_title ?? ''); ?>" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text"  value="<?php echo e($product_page_data->product_page_title ?? ''); ?>" name="option[product_page_title]" class="form-control">
								</div>
								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'product_page_icon',
										'input_id'=>'product_page_icon',
										'input_class'=>'product_page_image',
										'input_name'=>'option[product_page_banner]',
										'value'=>$product_page_data->product_page_banner ?? '',
										'preview'=>$product_page_data->product_page_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>

							
							<div class="tab-pane fade" id="cart_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$cart_page=get_option('cart_page',true);
								$cart_page=$cart_page->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','cart_page')); ?>">
									<?php echo csrf_field(); ?>
								
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($cart_page->cart_page_title ?? ''); ?>" name="option[cart_page_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[cart_page_description]" class="form-control"><?php echo e($cart_page->cart_page_description ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'cart_page_icon',
										'input_id'=>'cart_page_icon',
										'input_class'=>'cart_page_image',
										'input_name'=>'option[cart_page_banner]',
										'value'=>$cart_page->cart_page_banner ?? '',
										'preview'=>$cart_page->cart_page_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>

							<div class="tab-pane fade" id="wishlist_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$wishlist_page=get_option('wishlist_page',true);
								$wishlist_page=$wishlist_page->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','wishlist_page')); ?>">
									<?php echo csrf_field(); ?>
								
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($wishlist_page->wishlist_page_title ?? ''); ?>" name="option[wishlist_page_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[wishlist_page_description]" class="form-control"><?php echo e($wishlist_page->wishlist_page_description ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'wishlist_page_icon',
										'input_id'=>'wishlist_page_icon',
										'input_class'=>'wishlist_page_image',
										'input_name'=>'option[wishlist_page_banner]',
										'value'=>$wishlist_page->wishlist_page_banner ?? '',
										'preview'=>$wishlist_page->wishlist_page_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>
							<div class="tab-pane fade" id="checkout_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$checkout_page=get_option('checkout_page',true);
								$checkout_page=$checkout_page->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','checkout_page')); ?>">
									<?php echo csrf_field(); ?>
								
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($checkout_page->cart_page_title ?? ''); ?>" name="option[cart_page_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[cart_page_description]" class="form-control"><?php echo e($checkout_page->cart_page_description ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'checkout_page_icon',
										'input_id'=>'checkout_page_icon',
										'input_class'=>'checkout_page_image',
										'input_name'=>'option[checkout_page_banner]',
										'value'=>$checkout_page->checkout_page_banner ?? '',
										'preview'=>$checkout_page->checkout_page_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<div class="form-group">
									<label><?php echo e(__('Checkout Form Title :')); ?></label>
									<input type="text" value="<?php echo e($checkout_page->checkout_form_title ?? ''); ?>" name="option[checkout_form_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Checkout Description :')); ?></label>
									<textarea name="option[checkout_form_description]" class="form-control"><?php echo e($checkout_page->checkout_form_description ?? ''); ?></textarea>
								</div>

								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>

							<div class="tab-pane fade" id="blog_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$blog_page=get_option('blog_page',true);
								$blog_page=$blog_page->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','blog_page')); ?>">
									<?php echo csrf_field(); ?>
								
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($blog_page->blog_page_title ?? ''); ?>" name="option[blog_page_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[blog_page_description]" class="form-control"><?php echo e($blog_page->blog_page_description ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'blog_page_icon',
										'input_id'=>'blog_page_icon',
										'input_class'=>'blog_page_image',
										'input_name'=>'option[blog_page_banner]',
										'value'=>$blog_page->blog_page_banner ?? '',
										'preview'=>$blog_page->blog_page_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								

								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>
							

							<div class="tab-pane fade" id="menu_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$menu_page=get_option('menu_page',true);
								$menu_page=$menu_page->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','menu_page')); ?>">
									<?php echo csrf_field(); ?>
								<h3><?php echo e(__('Menu page header section')); ?></h3>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($menu_page->menu_page_title ?? ''); ?>" name="option[menu_page_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[menu_page_description]" class="form-control"><?php echo e($menu_page->menu_page_description ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'menu_page_icon',
										'input_id'=>'menu_page_icon',
										'input_class'=>'menu_page_image',
										'input_name'=>'option[menu_page_banner]',
										'value'=>$menu_page->menu_page_banner ?? '',
										'preview'=>$menu_page->menu_page_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<hr>
								<h3><?php echo e(__('Menu page product section')); ?></h3>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($menu_page->menu_product_section_title ?? ''); ?>" name="option[menu_product_section_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[menu_product_section_description]" class="form-control"><?php echo e($menu_page->menu_product_section_description ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Menu page ads')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'menu_page_product_ads_icon',
										'input_id'=>'menu_page_product_ads_icon',
										'input_class'=>'menu_page_product_ads_image',
										'input_name'=>'option[menu_page_product_ads_banner]',
										'value'=>$menu_page->menu_page_product_ads_banner ?? '',
										'preview'=>$menu_page->menu_page_product_ads_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<div class="form-group">
									<label><?php echo e(__('Ads Link :')); ?></label>
									<input type="text" name="option[menu_page_product_ads_link]"  value="<?php echo e($menu_page->menu_page_product_ads_link ?? ''); ?>" class="form-control">
								</div>
								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>

							<div class="tab-pane fade" id="products_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$products_page=get_option('products_page',true);
								$products_page=$products_page->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','products_page')); ?>">
									<?php echo csrf_field(); ?>
								<h3><?php echo e(__('Products page header section')); ?></h3>
								<div class="form-group">
									<label><?php echo e(__('Title :')); ?></label>
									<input type="text" value="<?php echo e($products_page->products_page_title ?? ''); ?>" name="option[products_page_title]" class="form-control">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description :')); ?></label>
									<textarea name="option[products_page_description]" class="form-control"><?php echo e($products_page->products_page_description ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'products_page_icon',
										'input_id'=>'products_page_icon',
										'input_class'=>'products_page_image',
										'input_name'=>'option[products_page_banner]',
										'value'=>$products_page->products_page_banner ?? '',
										'preview'=>$products_page->products_page_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<div class="form-group">
									<label><?php echo e(__('Products page ads')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'products_page_product_ads_banner',
										'input_id'=>'products_page_product_ads_banner',
										'input_class'=>'products_page_product_ads_banner',
										'input_name'=>'option[products_page_product_ads_banner]',
										'value'=>$products_page->products_page_product_ads_banner ?? '',
										'preview'=>$products_page->products_page_product_ads_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>
								<div class="form-group">
									<label><?php echo e(__('Ads Link :')); ?></label>
									<input type="text" name="option[products_page_product_ads_link]" class="form-control" value="<?php echo e($products_page->products_page_product_ads_link ?? ''); ?>">
								</div>
								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>

							<div class="tab-pane fade" id="settings_page" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$site_settings=get_option('site_settings',true);
								$site_settings=$site_settings->meta ?? '';
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','site_settings')); ?>">
									<?php echo csrf_field(); ?>
								<h6><?php echo e(__('Template primary settings')); ?></h6>
								<div class="form-group">
									<label><?php echo e(__('Footer Column 1:')); ?></label>
									<textarea name="option[footer_column1]" class="form-control"><?php echo e($site_settings->footer_column1 ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Footer Column 2:')); ?></label>
									<textarea name="option[footer_column2]" class="form-control"><?php echo e($site_settings->footer_column2 ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Footer Column 3:')); ?></label>
									<textarea name="option[footer_column3]" class="form-control"><?php echo e($site_settings->footer_column3 ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Footer Column 4:')); ?></label>
									<textarea name="option[footer_column4]" class="form-control"><?php echo e($site_settings->footer_column4 ?? ''); ?></textarea>
								</div>
								
								<div class="form-group">
									<label><?php echo e(__('Bottom Left Column:')); ?></label>
									<textarea name="option[bottom_left_column]" class="form-control"><?php echo e($site_settings->bottom_left_column ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Bottom Center Column:')); ?></label>
									<textarea name="option[bottom_center_column]" class="form-control"><?php echo e($site_settings->bottom_center_column ?? ''); ?></textarea>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Bottom Right Column:')); ?></label>
									<textarea name="option[bottom_right_column]" class="form-control"><?php echo e($site_settings->bottom_right_column ?? ''); ?></textarea>
								</div>
								<?php
								$scroll_to_top=$site_settings->scroll_to_top ?? 'yes';
								$cart_sidebar=$site_settings->cart_sidebar ?? 'yes';
								$preloader=$site_settings->preloader ?? 'yes';
								$bottom_bar=$site_settings->bottom_bar ?? 'yes';
								?>
								<div class="form-group">
									<label><?php echo e(__('Preloader')); ?></label>
									<select class="form-control" name="option[preloader]">
										<option value="yes" <?php if($preloader == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enable')); ?></option>
										<option value="no" <?php if($preloader == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disable')); ?></option>
									</select>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Scroll To Top Button')); ?></label>
									<select class="form-control" name="option[scroll_to_top]">
										<option value="yes" <?php if($scroll_to_top == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enable')); ?></option>
										<option value="no" <?php if($scroll_to_top == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disable')); ?></option>
									</select>
								</div>
								<div class="form-group">
									<label><?php echo e(__('Cart Sidebar')); ?></label>
									<select class="form-control" name="option[cart_sidebar]">
										<option value="yes" <?php if($cart_sidebar == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enable')); ?></option>
										<option value="no" <?php if($cart_sidebar == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disable')); ?></option>
									</select>
								</div>
								
								<div class="form-group">
									<label><?php echo e(__('Mobile bottom menubar')); ?></label>
									<select class="form-control" name="option[bottom_bar]">
										<option value="yes" <?php if($bottom_bar == 'yes'): ?> selected="" <?php endif; ?>><?php echo e(__('Enable')); ?></option>
										<option value="no" <?php if($bottom_bar == 'no'): ?> selected="" <?php endif; ?>><?php echo e(__('Disable')); ?></option>
									</select>
								</div>
								
								
								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>


							<div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="profile-tab4">
								<?php
								$contact_info=get_option('contact_page',true);
								$contact_info=$contact_info->meta ?? '';
								
								?>
								<form method="post" class="ajaxform" action="<?php echo e(route('seller.themeoption.update','contact_page')); ?>">
									<?php echo csrf_field(); ?>
								<h6><?php echo e(__('Contact Page')); ?></h6>
								<div class="form-group">
									<label><?php echo e(__('Title')); ?></label>
									<input type="text"  name="option[contact_page_title]" class="form-control" value="<?php echo e($contact_info->contact_page_title ?? ''); ?>" required="">
								</div>

								<div class="form-group">
									<label><?php echo e(__('Description')); ?></label>
									<textarea name="option[contact_des]" id="" cols="30" rows="10" class="form-control"><?php echo e($contact_info->contact_des ?? ''); ?></textarea>
								</div>

								<div class="form-group">
									<label><?php echo e(__('Page Banner')); ?></label>
									<?php echo e(mediasection([
										'preview_class'=>'contact_banner',
										'input_id'=>'contact_banner',
										'input_class'=>'contact_banner',
										'input_name'=>'option[contact_banner]',
										'value'=>$contact_info->contact_banner ?? '',
										'preview'=>$contact_info->contact_banner ?? 'admin/img/img/placeholder.png'
									])); ?>

								</div>

								<div class="form-group">
									<button class="btn btn-primary basicbtn"><?php echo e(__('Update')); ?></button>
								</div>
							  </form>
							</div>

						</div>


					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php echo e(mediasingle()); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin/assets/js/summernote-bs4.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/summernote.js')); ?>"></script>
<!-- JS Libraies -->
<script src="<?php echo e(asset('admin/plugins/dropzone/dropzone.min.js')); ?>"></script>

<!-- Page Specific JS File -->
<script src="<?php echo e(asset('admin/plugins/dropzone/components-multiple-upload.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/resto/admin/options.blade.php ENDPATH**/ ?>