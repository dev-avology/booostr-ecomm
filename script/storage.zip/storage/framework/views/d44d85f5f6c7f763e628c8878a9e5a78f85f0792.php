
<?php $__env->startSection('content'); ?>

<style>
a.cart-summary > span {
    display: inline;
    float: left;
    width: 100%;
}

p span.title{
    font-size: 12px;
}

.attr-variation-style{
    background: #eeebec;
    padding: 2px;
    border-radius: 2px;
    margin: 0px 2px;
}

/* add coupon code css */

.coupon-main-div {
    padding-left: 22px;
}

.apply-c-code .coupon-input-button {
  display: flex;
  flex-direction: row;
  padding: 6px 0px;
}

.apply-c-code .coupon-input-button .coupon-btn {
    background-color: #00c0ff;
    color: white;
    padding: -17px;
    /* margin: 7px 1px 27px 42px; */
    border: none;
    border-radius: 3px;
    cursor: pointer;
    font-size: 13px;
    width: 87px;
    height: 37px;
    padding-top: 9px;
    border-radius: 6px!important;
}

.apply-c-code .coupon-input-button .c-input {
    width: 224px;
    height: 42px;
    margin-top: 7px;
}

.apply-c-code h5{
    margin-left: 23px;
    font-size: 14px;
}

.coupon-main-div a{
    color:#00c0ff;
    font-weight: bold;
}

p#show_coupon_error {
    color: red;
    background: transparent;
}

.checkout-main span.price,.checkout-main span.price span{
    display: block;
}
.checkout-main span.price span.old-price{
    text-decoration: line-through;
}
</style>

 <!-- Spinner container -->
 <div id="page-loader" class="spinner-container" style="display:none;">
	<!-- Custom Spinner -->
	<div class="custom-spinner"></div>
 </div>

    <!-- Topbar Area -->
    <div class="topbar-area">
		

        <div class="container">
            <div class="row">
                <div class="row align-items-center">

                    <div class="col-lg-6 col-md-7 col-12">
                        <!-- Topbar Left -->
                        <div class="topbar-left">
                            <ul class="topbar-left-inner">
                                <?php if(!empty(tenant()->logo)): ?>
                                    <li><a href="#"><img src="<?php echo e(env('WP_URL')); ?><?php echo e(tenant()->logo); ?>"
                                                style="max-width: 80px;" /></a></li>
                                <?php else: ?>
                                    <li><a
                                            href="<?php echo e(url('/')); ?>"><?php echo e(ucfirst(str_replace(['-', '_'], ' ', tenant()->id))); ?></a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-5 col-12">
                        <!-- Topbar Right -->
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Start Checkout -->

        <section class="shop checkout section checkout-main">
            <div class="checkout-container">
                <h1 class="page-title"><?php echo e($page_data->cart_page_title ?? 'Checkout'); ?></h1>


                    <div class="row pb-5 breadcrumb">
                        <div class="col-lg-12">
                            <?php 
                            $club_info = tenant_club_info();
                            ?>
                          <a href="<?php echo e($club_info['club_url']); ?>"> <?php echo e($club_info['club_name']); ?> </a>  &nbsp;&nbsp;>>&nbsp;&nbsp;  <a href="<?php echo e($club_info['club_url']); ?>?tab=cart">Cart</a>  &nbsp;&nbsp;>>&nbsp;&nbsp;  Checkout
        
                        </div>
                    </div>
    
                <?php if(Cart::instance('default')->count() != 0): ?>
                    <form class="form orderform" id="payment-form" method="post"
                        action="<?php echo e(route('checkout.makeorder')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-8 col-12 col-65 container">

                                <div class="checkout-form  pb-3">
                                    <h3 class="mt-3 mb-1">Billing Address</h3>
                                    <em>Enter your payment method billing information below</em>
                                    <!-- Form -->
									<div class="row mt-3" id="error-msg">
									</div>
                                    <div class="row mt-3">
                                        <div class="col-lg-12 col-md-12 col-12">
                                            <?php if($errors->any()): ?>
                                                <div class="alert alert-danger">
                                                    <ul>
                                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($error); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(Session::has('error')): ?>
                                                <div class="alert alert-danger">
                                                    <ul>
                                                        <li><?php echo e(Session::get('error')); ?></li>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(Session::has('alert')): ?>
                                                <div class="alert alert-danger">
                                                    <ul>
                                                        <li><?php echo e(Session::get('alert')); ?></li>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-12">
                                            <div class="form-group">
                                                <label><i class="fa fa-user"></i><?php echo e(__('Full Name')); ?><span>*</span></label>
                                                <input type="text" name="name" id="billing-name"
                                                    data-shippingf="shipping-name" value="<?php echo e($customer['name']); ?>"
                                                    placeholder=""  class="required" data-msg="<?php echo e(__('Billing Full Name')); ?>" <?php if(!empty($customer['name'])): ?> <?php endif; ?>>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-12">
                                            <div class="form-group">
                                                <label><i
                                                        class="fa fa-envelope"></i><?php echo e(__('Email Address')); ?><span>*</span></label>
                                                <input value="<?php echo e($customer['email']); ?>" id="billing-email"
                                                    data-shippingf="shipping-email" type="email" name="email"
                                                    placeholder="" class="required" data-msg="<?php echo e(__('Billing Email')); ?>" required <?php if(!empty($customer['email'])): ?> <?php endif; ?>>
                                            </div>
                                            
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12">
                                            <div class="form-group">
                                                <label><i
                                                        class="fa fa-phone"></i><?php echo e(__('Phone Number')); ?><span>*</span></label>
                                                <input type="number" id="billing-phone" name="phone"
                                                    data-shippingf="shipping-phone"
                                                    value="<?php echo e(str_replace('-', '', $customer['phone'])); ?>" placeholder=""
                                                     maxlength="20" class="required" data-msg="<?php echo e(__('Billing Phone Number')); ?>" <?php if(!empty($customer['phone'])): ?> <?php endif; ?>>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-12 delivery_address_area">
                                            <div class="form-group">
                                                <label><i class="fa fa-map-marker"></i> <?php echo e(__('Address')); ?>

                                                    <span>*</span></label>
                                                <input type="text" class="location_input required" id="location_input"
                                                    data-shippingf="location_input1" name="billing[address]" placeholder=""
                                                     value="<?php echo e($customer['address']); ?>" data-msg="<?php echo e(__('Billing Address')); ?>" <?php if(!empty($customer['address'])): ?> <?php endif; ?>>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 delivery_address_city">
                                            <div class="form-group">
                                                <label><i class="fa fa-building"></i> <?php echo e(__('City')); ?>

                                                    <span>*</span></label>
                                                <input type="text" class="location_input required" id="location_city"
                                                    data-shippingf="location_city1" name="billing[city]" placeholder=""
                                                     value="<?php echo e($customer['city']); ?>" data-msg="<?php echo e(__('Billing City')); ?>" <?php if(!empty($customer['city'])): ?> <?php endif; ?>>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 delivery_address_state">
                                            <div class="form-group">
                                                <label> <i class="fa fa-map"></i><?php echo e(__('State')); ?> <span>*</span></label>


                                                <select class="location_input nice-select add-coupon-check required" id="location_state"
                                                        data-shippingf="location_state1" name="billing[state]" data-msg="<?php echo e(__('Billing State')); ?>" <?php if(!empty($customer['state'])): ?> <?php endif; ?>>
                                                    <?php $__currentLoopData = $states_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if($key == $customer['state']): ?> selected <?php endif; ?>
                                                            value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 delivery_address_country">
                                            <div class="form-group">
                                                <label> <i class="fa fa-globe"></i>
                                                    <?php echo e(__('Country')); ?> <span>*</span></label>
                                                <select id="billing-country" name="billing[country]"
                                                    data-shippingf="billing-country1" class="nice-select required" data-msg="<?php echo e(__('Billing Country')); ?>">
                                                    <option value="USA">United State</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 post_code_area">
                                            <div class="form-group">
                                                <label><i class="fa fa-envelope"></i>
                                                    <?php echo e(__('Zip Code')); ?><span>*</span></label>
                                                <input type="text" id="post_code" name="billing[post_code]"
                                                    data-shippingf="post_code1" placeholder=""
                                                    value="<?php echo e($customer['zip']); ?>"  class="required" data-msg="<?php echo e(__('Billing Postal Code')); ?>" <?php if(!empty($customer['zip'])): ?> <?php endif; ?>>
                                            </div>
                                        </div>

                                        <div class="col-lg-12 col-md-12 col-12">
                                            <div class="form-group create-account">
                                                <input id="shipping_address" name="shipping_same_as_billing"
                                                    type="checkbox" value="1" checked>
                                                <label
                                                    for="shipping_address"><?php echo e(__('Shipping address same as billing')); ?></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mt-3 shipping_address_area none" style="display:none">
                                        <div class="col-lg-6 col-md-6 col-12">
                                            <div class="form-group">
                                                <label><i
                                                        class="fa fa-user"></i><?php echo e(__('Full Name')); ?><span>*</span></label>
                                                <input type="text" id="shipping-name" name="shipping[name]"
                                                    value="<?php echo e($customer['name']); ?>" placeholder=""  class="required" data-msg="<?php echo e(__('Shipping Full Name')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12">
                                            <div class="form-group">
                                                <label><i
                                                        class="fa fa-phone"></i><?php echo e(__('Phone Number')); ?><span>*</span></label>
                                                <input type="number" id="shipping-phone" name="shipping[phone]"
                                                    value="<?php echo e(str_replace('-', '', $customer['phone'])); ?>" placeholder=""
                                                     maxlength="20" class="required" data-msg="<?php echo e(__('Shipping Phone Number')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-12 delivery_address_area">
                                            <div class="form-group">
                                                <label><i class="fa fa-map-marker"></i> <?php echo e(__('Address')); ?>

                                                    <span>*</span></label>
                                                <input type="text" class="location_input required" id="location_input1"
                                                    name="shipping[address]" placeholder="" 
                                                    value="<?php echo e($customer['address']); ?>" data-msg="<?php echo e(__('Shipping Address')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 delivery_address_city">
                                            <div class="form-group">
                                                <label><i class="fa fa-building"></i> <?php echo e(__('City')); ?>

                                                    <span>*</span></label>
                                                <input type="text" class="location_input required" id="location_city1"
                                                    name="shipping[city]" placeholder="" 
                                                    value="<?php echo e($customer['city']); ?>" data-msg="<?php echo e(__('Shipping City')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 delivery_address_state">
                                            <div class="form-group">
                                                <label> <i class="fa fa-map"></i><?php echo e(__('State')); ?> <span>*</span></label>
                                                <select class="location_input add-coupon-check2 nice-select required" id="location_state1"
                                                    name="shipping[state]" data-msg="<?php echo e(__('Shipping State')); ?>">
                                                    <?php $__currentLoopData = $states_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if($key == $customer['state']): ?> selected <?php endif; ?>
                                                            value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 delivery_address_country">
                                            <div class="form-group">
                                                <label> <i class="fa fa-globe"></i><?php echo e(__('Country')); ?> <span>*</span></label>
                                                <select id="shipping-country" name="shipping[country]"
                                                    class="nice-select required" data-msg="<?php echo e(__('Shipping Country')); ?>">
                                                    <option value="USA">United State</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-12 post_code_area">
                                            <div class="form-group">
                                                <label><i class="fa fa-envelope"></i><?php echo e(__('Zip Code')); ?><span>*</span></label>
                                                <input type="text" id="post_code1" class="required post_code_class" name="shipping[post_code]"
                                                    placeholder="" value="<?php echo e($customer['zip']); ?>"  data-msg="<?php echo e(__('Shipping Postal Code')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Shopping Cart -->
                                <div class="checkout-form  pb-3">
                                    <div class="form-row">
                                        <h3><?php echo e(__('Payment Method')); ?></h3>
                                        <div id="card-element">

                                            <label for="fname">The following payment types are accepted. Please enter your payment information below.</label>
                                            <div class="icon-container">
                                                <i class="fa fa-cc-visa" style="color:navy;"></i>
                                                <i class="fa fa-cc-amex" style="color:blue;"></i>
                                                <i class="fa fa-cc-mastercard" style="color:red;"></i>
                                                <i class="fa fa-cc-discover" style="color:orange;"></i>
                                            </div>
                                            <label for="cardnumber">Credit card number</label>
                                            <div id="cardnumber"></div>
                                            <div class="row">
                                                <div class="col-50">
                                                    <label for="cardexpiry">Exp Month</label>
                                                    <div id="cardexpiry"></div>
                                                </div>
                                                <div class="col-25">
                                                    <label for="cardcvv">CVV</label>
                                                    <div id="cardcvv"></div>
                                                </div>
                                                <div class="col-25">
                                                    <label for="cardpostal">ZIP</label>
                                                    <div id="cardpostal"></div>
                                                </div>
                                            </div>

                                        </div>
                                        <!-- Used to display form errors. -->
                                        <div id="card-errors" role="alert"></div>
                                    </div>
                                    <input type="hidden" id="publishable_key"
                                        value="<?php echo e($payment_data['publishable_key']); ?>">
                                </div>
                                <!--/ End Shopping Cart -->

                            </div>
                            <div class="col-lg-4 col-12 col-35">
                                <div class="order-details container carts-right">
                                    <!-- Order Widget -->
                                    <div class="single-widget">

                                        <div class="">
                                            <h2><?php echo e(__('CART SUMMARY')); ?><span class="price" style="color:black"><i
                                                        class="fa fa-shopping-cart"></i>
                                                    <b><?php echo e(Cart::count()); ?></b></span></h2>
                                            <?php $__currentLoopData = Cart::instance('default')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p id="<?php echo e($item->rowId); ?>"><a href="#" class="cart-summary"> <img src="<?php echo e($item->options->preview); ?>"
                                                            alt="img"><span class="title"><?php echo e($item->name); ?>

                                                           
						<?php if(count($item->options['options'])){
                          echo "<span class='product-description' style='font-size: 9px;display: flow;'>";
						 foreach($item->options['options'] as $option => $selected_option){
                            $product_options = $selected_option->varitionOptions;
                            foreach($selected_option->varitions as $sel_val){
                                $cur_opt_name = $product_options->filter(function ($x) use ($sel_val) {
                                return $x->id == $sel_val->pivot->productoption_id;
                            });
    						   echo "<strong class='attr-variation-style'>".$sel_val->name."</strong>";
                            }
                           						
						 }						
						  echo "</span>";	 						
						 } ?>


															</span></a><span class="d-qty"><?php echo e($item->qty); ?> </span> <span
                                                        class="price"><span><?php echo e(get_option('currency_data', true)->currency_icon); ?><?php echo e(number_format($item->price*$item->qty, 2)); ?></span></span>
                                                </p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <hr>
                                        </div>
                                        <?php if($pickup_order == 'on'): ?>
                                            <div class="order-type-section">
                                                <input type="radio" name="order_method" id="is_pickup"
                                                    class="order_method <?php echo e($pickup_order == 'off' ? 'none' : ''); ?>"
                                                    value="pickup" <?php if($order_method == 'pickup'): ?> checked="" <?php endif; ?>>
                                                <label for="is_pickup"><?php echo e(__('pickup')); ?></label>

                                                <input type="radio" name="order_method" id="is_pickup1"
                                                    class="order_method" value="delivery"
                                                    <?php if($order_method == 'delivery'): ?> checked="" <?php endif; ?>>
                                                <label for="is_pickup1"><?php echo e(__('delivery')); ?></label>

                                            </div>
                                        <?php else: ?>
                                            <input type="hidden" name="order_method" class="order_method none"
                                                value="delivery">
                                        <?php endif; ?>

                                        <div class="content">
                                            <div class="coupon-main-div">
                                                <div class="apply-c-code">
                                                    <p id="show_coupon_error" style="display:none;"></p>
                                                    <div class="coupon-input-button">
                                                        <input type="text" class="c-input" placeholder="Enter coupon" id="couponInput">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                        <button type="button" class="btn btn-primary coupon-btn" id="applyCouponBtn">Apply</button>

                                                        <button style="display:none;" type="button" class="btn btn-danger coupon-btn" id="removeCouponBtn">Remove</button>
                                                    </div>
                                                
                                                </div>
                                            </div>
                                            
                                            <ul>
                                               
                                                <li><?php echo e(__('Subtotal')); ?>

                                                    <span class="cart_subtotal">
                                                        0.00
                                                    </span>
                                                </li>
                                                <li>(-) <?php echo e(__('Discount')); ?>

                                                    <span class="cart_discount">
                                                        0.00
                                                    </span>
                                                </li>

                                                <li>(+) <?php echo e(__('Tax')); ?>

                                                    <span class="cart_tax">
                                                        0.00
                                                    </span>
                                                </li>
                                                <li>(+) <?php echo e(__('Delivery fee')); ?><span class="shipping_fee">0.00</span>
                                                </li>


                                                <li class="last"><?php echo e(__('Total')); ?><span
                                                        class="cart_total">0.00</span></li>

                                                

                                            </ul>
                                        </div>
                                    </div>
                                    <?php if($order_settings->shipping_amount_type != 'distance'): ?>
                                        <div class="single-widget shipping_method_area">
                                            <h2><?php echo e(__('Shipping Method')); ?></h2>
                                            <div class="content">
                                                <div class="checkbox shipping_render_area">

                                                    <label class="checkbox-inline shipping_method"
                                                        for="shipping<?php echo e($shipping_methods['method_type']); ?>">
                                                        <input name="shipping_method" class="shipping_item"
                                                            value="<?php echo e($shipping_methods['method_type']); ?>"
                                                            data-price="<?php echo e($shipping_methods['base_pricing']); ?>"
                                                            data-shippingInfo='<?php echo json_encode($shipping_methods); ?>'
                                                            id="shipping<?php echo e($shipping_methods['method_type']); ?>"
                                                            type="radio"> <?php echo e($shipping_methods['label']); ?>

                                                    </label>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <!--/ End Order Widget -->

                                    <!--/ End Order Widget -->

                                    <!-- Button Widget -->
                                    <div class="single-widget get-button">
                                        <div class="content">
                                            <div class="button">
                                                <input type="hidden" id="shipping_fee" name="shipping_fee">
                                                <input type="hidden" id="total_price" name="total_price">
                                                <button type="submit" class="btn submit_btn submitbtn"
                                                    id="submit_btn"><?php echo e(__('Place Order')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    <!--/ End Button Widget -->
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="wpuid" value="<?php echo e($customer['wpuid']); ?>">

                    </form>
                <?php else: ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(__('No Cart Item Available For Checkout')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </section>
        <!--/ End Checkout -->
        <input type="hidden" id="subtotal" value="<?php echo e(Cart::instance('default')->subtotal()); ?>">
        <input type="hidden" id="tax" value="<?php echo e(Cart::instance('default')->tax()); ?>">
        <input type="hidden" id="credit_card_fee"
            value="<?php echo e(credit_card_fee(Cart::instance('default')->total() + $shipping_price)); ?>">
        <input type="hidden" id="booster_platform_fee"
            value="<?php echo e(booster_club_chagre(Cart::instance('default')->total() + $shipping_price)); ?>">
        <input type="hidden" id="total" value="<?php echo e(Cart::instance('default')->total()); ?>">
        <input type="hidden" id="discount" value="<?php echo e(Cart::instance('default')->discount()); ?>">

        <input type="hidden" id="totalWeight" value="<?php echo e(Cart::instance('default')->weight()); ?>">
        <input type="hidden" id="totalItem" value="<?php echo e(Cart::instance('default')->count()); ?>">


        <input type="hidden" id="latitude" value="<?php echo e(tenant('lat')); ?>">
        <input type="hidden" id="longitude" value="<?php echo e(tenant('long')); ?>">
        <input type="hidden" id="city" value="<?php echo e($invoice_data->store_legal_city ?? ''); ?>">

        <footer class="container">
            <div class="row">
                <div class="col-lg-12 container" style="text-align:center;">

                    <a href="<?php echo e(route('store.page', ['slug' => 'terms-and-conditions'])); ?>" target="_blank"> Terms and
                        conditions</a> |
                    <a href="<?php echo e(route('store.page', ['slug' => 'privacy-policy'])); ?>" target="_blank">Privacy Policy</a> |
                    <a href="<?php echo e(route('store.page', ['slug' => 'return-policy'])); ?>" target="_blank">Return Policy</a>

                </div>
            </div>
        </footer>


    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('js'); ?>
	<style>
        /* Center the fixed spinner */
        .spinner-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.5); /* Transparent white background */
            display: flex;
            justify-content: center;
            align-items: center;
			z-index: 999;
        }

        /* Style the spinner */
        .custom-spinner {
            border: 3px solid transparent;
            border-top: 3px solid #007bff; /* Change the color here */
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 2s linear infinite;
        }

        /* Spinner animation */
        @keyframes  spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>


     
        <script type="text/javascript">
            "use strict";

            var subtotal = parseFloat($('#subtotal').val());
            var tax = parseFloat($('#tax').val());
            var total = parseFloat($('#total').val());
            var price = <?php echo e($shipping_price); ?>;
            var credit_card_fee = parseFloat($('#credit_card_fee').val());
            var booster_platform_fee = parseFloat($('#booster_platform_fee').val());

            var new_total = subtotal;
            var apply_tax_url = "<?php echo e(route('checkout.applyTax')); ?>";
            var store_info = <?php echo Tenant('club_info'); ?>;
            var currency_icon = "<?php echo e(get_option('currency_data', true)->currency_icon); ?>";
            var discount = parseFloat($('#discount').val());
        </script>
        <?php if($source_code == 'off'): ?>
            <script type="text/javascript" src="<?php echo e(asset('theme/disable-source-code.js')); ?>"></script>
        <?php endif; ?>
        <script type="text/javascript" src="<?php echo e(asset('checkout/js/checkout.js')); ?>"></script>

        <?php if(1): ?>
            <script async defer
                src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCmimJcxCmMIgBR0G0UKmQAgfr7RSS8pDg&libraries=places&radius=5&location=<?php echo e(tenant('lat')); ?>%2C<?php echo e(tenant('long')); ?>&callback=initialize">
            </script>
            <script type="text/javascript">
                "use strict";
                if ($('#my_lat').val() != null) {
                    localStorage.setItem('lat', $('#my_lat').val());
                }
                if ($('#my_long').val() != null) {
                    localStorage.setItem('long', $('#my_long').val());
                }
                if ($('#location_input').val() != null) {
                    localStorage.setItem('location', $('#location_input').val());
                }
                if (localStorage.getItem('location') != null) {
                    var locs = localStorage.getItem('location');
                } else {
                    var locs = "";
                }
                $('#location_input').val(locs);
                if (localStorage.getItem('lat') !== null) {
                    var lati = localStorage.getItem('lat');
                    $('#my_lat').val(lati)
                } else {
                    var lati = "<?php echo e(tenant('lat')); ?>";
                }
                if (localStorage.getItem('long') !== null) {
                    var longlat = localStorage.getItem('long');
                    $('#my_long').val(longlat)
                } else {
                    var longlat = "<?php echo e(tenant('long')); ?>";
                }

                const maxRange = "<?php echo e($order_settings->google_api_range ?? 0); ?>";
                const resturentlocation = "<?php echo e($invoice_data->store_legal_address ?? ''); ?>";
                const feePerkilo = "<?php echo e($order_settings->delivery_fee ?? 0); ?>";
                var mapOptions;
                var map;
                var marker;
                var searchBox;
                var city;
            </script>
        <?php endif; ?>
        <script type="text/javascript" src="<?php echo e(asset('checkout/js/google-api.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
        <script src="https://js.stripe.com/v3/"></script>
        <script src="<?php echo e(asset('checkout/js/stripe.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/store/checkout/checkout.blade.php ENDPATH**/ ?>