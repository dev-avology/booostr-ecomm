

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
       <div class="row">
        <div class="col-md-12">
            </div>
            <div class="col-md-12">
                <form method="post" id="ajaxform"  action="<?php echo e(route('admin.users.genupdate')); ?>">
                    <?php echo csrf_field(); ?>
                    <h4 class="mb-20"><?php echo e(__('Edit General Settings')); ?></h4>
                    <div class="custom-form">
                        <div class="form-group">
                            <label for="name"><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" readonly id="name" class="form-control" required placeholder="Enter User's  Name" value="<?php echo e($info->name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email"><?php echo e(__('Email')); ?></label>
                            <input type="text" name="email" readonly id="email" class="form-control" required placeholder="Enter Email"  value="<?php echo e($info->email); ?>">
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-info basicbtn"><?php echo e(__('Update')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/admin/settings/my_settings.blade.php ENDPATH**/ ?>