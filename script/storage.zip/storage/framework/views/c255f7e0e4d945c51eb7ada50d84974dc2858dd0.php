

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=> 'Site Settings'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section-body">
  <div class="row">
   <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-cog"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('General')); ?></h4>
        <p><?php echo e(__('View and update your store details')); ?></p>
        <a href="<?php echo e(route('seller.site-settings.show','general')); ?>" class="card-cta"><?php echo e(__('Change Setting')); ?><i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-cog"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Menu Settings')); ?></h4>
        <p><?php echo e(__('View and update your menu details')); ?></p>
        <a href="<?php echo e(route('seller.menu.index')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-map-marked-alt"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Locations')); ?></h4>
        <p><?php echo e(__('Manage the places you fulfill orders and sell products')); ?></p>
        <a href="<?php echo e(route('seller.location.index')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-money-bill-alt"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Payments')); ?></h4>
        <p><?php echo e(__('Enable and manage your store payment providers')); ?></p>
        <a href="<?php echo e(route('seller.payment.gateway')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="far fa-bell"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Notifications')); ?></h4>
        <p><?php echo e(__('Manage Notifications sent to you and your customers')); ?></p>
        <a href="<?php echo e(url('/seller/notification')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
         <i class="fas fa-globe-americas"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Store languages')); ?></h4>
        <p><?php echo e(__('Manage the languages your customers can view on your orders')); ?></p>
        <a href="<?php echo e(route('seller.language.index')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-truck"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Shipping and delivery')); ?></h4>
        <p><?php echo e(__('Manage how you ship order to customers')); ?></p>
        <a href="<?php echo e(url('/seller/shipping')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-user-shield"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Admins')); ?></h4>
        <p><?php echo e(__('Manage Admins')); ?></p>
       
        <a href="<?php echo e(route('seller.admin.index')); ?>" class="card-cta"><?php echo e(__('Admins Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
   <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-images"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Files')); ?> </h4>
        <p><?php echo e(__('Manage your uploaded files')); ?></p>
        <p><?php echo e(__('Total :')); ?> <span><?php echo e(number_format(\App\Models\Media::sum('size'),2).'MB'); ?></span></p>
        <a href="<?php echo e(url('/seller/medias')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-crop"></i>
      </div>
      <div class="card-body">
        <h4> <?php if(tenant('image_optimization') != 'on' ): ?> <i class="fa fa-lock text-danger"></i> <?php endif; ?> <?php echo e(__('Image Optimization')); ?></h4>
        <p><?php echo e(__('Optimize your uploaded images for better performance and reduce storage size')); ?></p>
        <a href="<?php echo e(url('/seller/mediacompress')); ?>" class="card-cta"><?php echo e(__('Visit')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
 
  <div class="col-lg-6">
    <div class="card card-large-icons">
      <div class="card-icon bg-primary text-white">
        <i class="fas fa-images"></i>
      </div>
      <div class="card-body">
        <h4><?php echo e(__('Theme')); ?></h4>
        <p><?php echo e(__('Change your store theme')); ?></p>
        <a href="<?php echo e(url('/seller/theme')); ?>" class="card-cta"><?php echo e(__('Change Settings')); ?> <i class="fas fa-chevron-right"></i></a>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/settings/sitesettings.blade.php ENDPATH**/ ?>