<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/summernote/summernote-bs4.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('head'); ?>

<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Edit Product - '.$info->title,'prev'=> url('seller/product')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.storenotification','data' => []]); ?>
<?php $component->withName('storenotification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('product_content'); ?>

<form class="ajaxform" action="<?php echo e(route('seller.product.update',$info->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>
    <div class="tab-pane fade show active" id="general_info" role="tabpanel" aria-labelledby="home-tab4">
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Name :')); ?> </label>
            <div class="col-lg-12">
                <input type="text" name="name" required="" class="form-control" placeholder="Enter Product Name" value="<?php echo e($info->title); ?>">
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Slug :')); ?> </label>
            <div class="col-lg-12">
                <input type="text" name="slug" required="" class="form-control" placeholder="Enter Product Slug" value="<?php echo e($info->slug); ?>">
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Short Description :')); ?> </label>
            <div class="col-lg-12">
                <textarea name="short_description" maxlength="500" class="form-control h-150"><?php echo e($info->excerpt->value ?? ''); ?></textarea>
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Long Description :')); ?> </label>
            <div class="col-lg-12">
                <textarea name="long_description" class="form-control summernote"><?php echo e($info->description->value ?? ''); ?></textarea>
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Select Product Category')); ?> : </label>
            <div class="col-lg-12">
                <select name="categories[]" multiple="" class="select2 form-control">

                    <?php echo e(NastedCategoryList('category',$selected_categories)); ?>

                </select>
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Select Product Type')); ?> : </label>
            <div class="col-lg-12">
                <select name="categories[]" class="selectric form-control">
                    <?php if(isset($product_type) && !empty($product_type)): ?>
                        <?php $__currentLoopData = $product_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($row->id); ?>" <?php if(in_array($row->id,$selected_categories)): ?> selected <?php endif; ?>><?php echo e($row->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>;
                </select>

             
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Select Product Brand')); ?> : </label>
            <div class="col-lg-12">
                <select name="categories[]"  multiple="" class="form-control select2">

                    <?php echo e(NastedCategoryList('brand',$selected_categories)); ?>

                </select>
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Select Product Tags')); ?> : </label>
            <div class="col-lg-12">
                <select name="categories[]" multiple="" class="form-control select2">

                    <?php echo e(NastedCategoryList('tag',$selected_categories)); ?>

                </select>
                <input type="hidden" name="type" value="general">
            </div>
        </div>

        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Select Featured Type')); ?> : </label>
            <div class="col-lg-12">
                <select name="categories[]" class="form-control selectric">
                    <option value="" selected=""></option>
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($row->id); ?>" <?php if(in_array($row->id,$selected_categories)): ?> selected <?php endif; ?>><?php echo e($row->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('List On')); ?> : </label>
            <div class="col-lg-4">
                <input type="radio" name="list_type" value="0" <?php if($info->list_type == 0): ?> checked <?php endif; ?> /> All
            </div>
            <div class="col-lg-4">
                <input type="radio" name="list_type" value="1" <?php if($info->list_type == 1): ?> checked <?php endif; ?> /> Web Only
            </div>
            <div class="col-lg-4">
                <input type="radio" name="list_type" value="2" <?php if($info->list_type == 2): ?> checked <?php endif; ?> /> POS Only
            </div>
        </div>
        <div class="from-group row mb-2">
            <label for="" class="col-lg-12"><?php echo e(__('Status')); ?> : </label>
            <div class="col-lg-12">
                <select name="status" class="form-control selectric">
                    <option value="1" <?php if($info->status == 1): ?> selected <?php endif; ?>><?php echo e(__('Publish')); ?></option>
                    <option value="0" <?php if($info->status == 0): ?> selected <?php endif; ?>><?php echo e(__('Draft')); ?></option>
                </select>
            </div>
        </div>
        <div class="from-group  mb-2">
            <button class="btn btn-primary basicbtn col-lg-2" type="submit"><i class="far fa-save"></i> <?php echo e(__('Update')); ?></button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('admin/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/summernote-bs4.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/summernote.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.product.productmain',['product_id'=>$id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/product/edit.blade.php ENDPATH**/ ?>