

<?php $__env->startPush('css'); ?>
<!-- CSS Libraries -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/dropzone/dropzone.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<section class="section">
   
   <div class="section-header">
      <a href="<?php echo e(url('seller/brand')); ?>" class="btn btn-primary mr-2">
            <i class="fas fa-arrow-left"></i>
      </a>
      <h1><?php echo e(__('Edit Brand')); ?></h1>
   </div>

   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.storenotification','data' => []]); ?>
<?php $component->withName('storenotification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

   
   <div class="row">
      <div class="col-lg-12">
         <form class="ajaxform" method="post" action="<?php echo e(route('seller.category.update',$info->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <div class="row">
               
               <div class="col-lg-5">
                  <strong><?php echo e(__('Image')); ?></strong>
                  <p><?php echo e(__('Upload brand image here')); ?></p>
               </div>
               
               
               <div class="col-lg-7">
                  <div class="card">
                     <div class="card-body">
                        <?php echo e(mediasection(['value'=>$info->preview->content ?? '','preview'=> $info->preview->content ?? 'admin/img/img/placeholder.png'])); ?>

                     </div>
                  </div>
               </div>
               
            </div>
            <div class="row">
               
               <div class="col-lg-5">
                  <strong><?php echo e(__('Information')); ?></strong>
                  <p><?php echo e(__('Edit your brand details and necessary information from here')); ?></p>
               </div>
               
               
               <div class="col-lg-7">
                  <div class="card">
                     <div class="card-body">
                         <div class="from-group row mb-2">
                                <label for="" class="col-lg-12"><?php echo e(__('Name')); ?> : </label>
                                <div class="col-lg-12">
                                    <input value="<?php echo e($info->name); ?>" type="text" name="name" class="form-control" placeholder="Enter Brand Name">
                                </div>
                            </div>
                             <div class="from-group row mb-2">
                                <label for="" class="col-lg-12"><?php echo e(__('Slug')); ?> : </label>
                                <div class="col-lg-12">
                                    <input value="<?php echo e($info->slug); ?>" type="text" name="slug" class="form-control" placeholder="Enter Brand Slug">
                                </div>
                            </div>
                            <div class="from-group row mb-2">
                                <label for="" class="col-lg-12"><?php echo e(__('Description :')); ?> </label>
                                <div class="col-lg-12">
                                    <textarea  name="description" class="form-control h-150"><?php echo e($info->description->content ?? ''); ?></textarea>
                                </div>
                            </div>
                            <div class="from-group row mb-2">
                              <label for="" class="col-lg-12"><?php echo e(__('Is Featured ?')); ?> : </label>
                              <div class="col-lg-12">
                                 <select name="featured"  class="form-control">
                                    <option value="1" <?php if($info->featured == 1): ?> selected <?php endif; ?>><?php echo e(__('Yes')); ?></option>
                                    <option value="0" <?php if($info->featured == 0): ?> selected <?php endif; ?>><?php echo e(__('No')); ?></option>
                                 </select>
                              </div>
                           </div>
                            <input type="hidden" name="type" value="<?php echo e($info->type); ?>">
                            <div class="row">
                                <div class="col-lg-12">
                                    <button class="btn btn-primary basicbtn" type="submit"><?php echo e(__('Save')); ?></button>
                              </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>
      </div>
   </div>
</section>
<?php echo e(mediasingle()); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
 <!-- JS Libraies -->
<script src="<?php echo e(asset('admin/plugins/dropzone/dropzone.min.js')); ?>"></script>
<!-- Page Specific JS File -->
<script src="<?php echo e(asset('admin/plugins/dropzone/components-multiple-upload.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/media.js')); ?>"></script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/brand/edit.blade.php ENDPATH**/ ?>