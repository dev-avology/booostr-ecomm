
<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=> 'Themes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-body">
        <div class="card">
            
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <div class="single-main-theme">
                            <div class="theme-main-img">
                                <img class="img-fluid" src="<?php echo e(asset($item->asset_path.'/screenshot.png')); ?>" alt="">
                            </div>
                            <div class="theme-name">
                                <h3><?php echo e($item->name); ?></h3>
                            </div>
                            <?php if(tenant('theme') == $item->view_path): ?>
                            <div class="theme-btn">
                                <a href="javascript:void(0)" class="btn btn-info btn-lg w-100"><?php echo e(__('Installed')); ?></a>
                            </div>
                            <?php else: ?> 
                            <div class="theme-btn">
                                <a href="<?php echo e(route('seller.theme.install',$item->name)); ?>" class="btn btn-primary btn-lg w-100"><?php echo e(__('Install')); ?></a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/theme/index.blade.php ENDPATH**/ ?>