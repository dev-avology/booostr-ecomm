
<?php $__env->startSection('content'); ?>

		<!-- Start Breadcrumbs Area -->
		<div class="breadcrumbs" style="background-image: url(<?php echo e(asset($home_data->product_page_banner ?? '')); ?>); ">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-8 col-12">
						<div class="breadcrumbs-content">
							<h1 class="page-title"><?php echo e($info->title); ?></h1>
							<p><?php echo e($info->excerpt->value ?? ''); ?></p>
						</div>
						<ul class="breadcrumb-nav">
							<li><a href="<?php echo e(url('/')); ?>"><i class="icofont-home"></i> <?php echo e(__('Home')); ?></a></li>
							<li><i class="icofont-fast-food"></i> <?php echo e($info->title); ?></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Breadcrumbs Area -->
		
		<!-- Shop Single -->
		<section class="shop single section">
			<div class="container">
				<div class="top-content">
					<div class="row align-items-center">
						<div class="col-lg-5 col-12">
							<!-- product details image -->
							<div class="product-details-image">
								<div class="main-preview-image">
									<div class="tab-content product-image" id="pills-tabContent">
										<?php $__currentLoopData = $galleries ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="tab-pane fade  <?php echo e($key == 0 ? 'show active' : ''); ?> " id="pills-home<?php echo e($key); ?>" role="tabpanel" aria-labelledby="pills-home-tab<?php echo e($key); ?>">
											<div class="single-product-image">
												<img src="<?php echo e(asset($row)); ?>" alt="<?php echo e($info->title); ?>">
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
										
										
									</div>
								</div>
								<ul class="nav-pills nav flex-nowrap product-thumbs" id="pills-tab" role="tablist">
									
									<?php $__currentLoopData = $galleries ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li class="single-thumbs" role="presentation">
										<a class="<?php echo e($key == 0 ? 'active' : ''); ?> " id="pills-home-tab<?php echo e($key); ?>" data-bs-toggle="pill" href="#pills-home<?php echo e($key); ?>" role="tab" aria-controls="pills-home" aria-selected="true">
											<img height="100" src="<?php echo e(asset($row)); ?>" alt="<?php echo e($info->title); ?>">
										</a>
									</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									
									
									
								</ul>
							</div>
							<!-- product details image -->
						</div>
						<div class="col-lg-6 col-12">
							<div class="single-item-des">
								<!-- Description -->
								<div class="short">
									<h4><?php echo e($info->title); ?></h4>
									
									<div class="rating-main">
										<ul class="rating">
											<?php for($i=1; $i <= 5; $i++): ?> 
											<li><i class="icofont-star <?php echo e($i <= $info->rating ? 'star' : ''); ?>"></i></li>
											<?php endfor; ?>
										</ul>
										<a href="javascript:void(0)" class="total-review">(<?php echo e($info->reviews_count); ?>) Reviews</a>
									</div>

									<p class="price price_area"> <?php echo e(count($info->optionwithcategories ?? []) == 0 ? $info->price->price ?? '' : ''); ?> </p>
									<div class="product-tag stock_status <?php if(count($info->optionwithcategories ?? []) != 0): ?> none <?php endif; ?>"><p class="cat">Availability: <span class="stock_status_display"><?php if(count($info->optionwithcategories ?? []) == 0): ?> <a href="javascript:void(0)"> <?php echo e($info->price->stock_status == 1 ? 'In Stock' : 'Out of stock'); ?> </a> <?php endif; ?></span></p></div>
									<p class="description">
										<?php echo e($info->excerpt->value ?? ''); ?>

									</p>
								</div>
								 <form class="product_option_form" method="post" action="<?php echo e(route('add.tocart')); ?>">
								 	<?php echo csrf_field(); ?>
								 	<input type="hidden" name="id" value="<?php echo e($info->id); ?>">
								 	<?php if(count($info->optionwithcategories ?? []) == 0): ?>
								 	<input 
										class=" none pricesvariationshide" 
										data-stockstatus="<?php echo e($info->price->stock_status); ?>"  
										data-stockmanage="<?php echo e($info->price->stock_manage); ?>" 
										data-sku="<?php echo e($info->price->sku); ?>" 
										data-qty="<?php echo e($info->price->qty); ?>"  
										data-oldprice="<?php echo e($info->price->old_price); ?>" 
										data-price="<?php echo e($info->price->price); ?>" 
										type="radio" 
										checked
										>
								   <?php endif; ?>		
								<!--/ End Description -->
								<?php echo $__env->make('theme.resto.components.variations',['info'=>$info ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<!-- Product Buy -->
								<div class="product-buy">
									<div class="quantity">
										<h6><?php echo e(__('Quantity')); ?> :</h6>
										<div class="quantity-container product-quantity">
											<div class="sp-quantity single-page">
											  <button type="button" class="inline arrow sp-minus   fff"><a class="ddd minus" data-multi="-1">-</a></button>
											  <div class="inline sp-input">
												<input type="text" class="quntity-input input_qty" name="qty" value="1">
											  </div>
											  <button type="button" class="inline arrow sp-plus  fff"><a class="ddd cart_increase plus" data-multi="1">+</a></button>
											</div>
										</div>
									</div>
									<div class="add-to-cart button"><button type="submit" class="btn add_to_cart_form_btn"><?php echo e(__('Add to cart')); ?></button></div>

								</div>
								<p class="text-danger none qty_display"><span class="maxqty"></span> : <?php echo e(__('pieces available')); ?></p>
								 </form>
								<!--/ End Product Buy -->
								<?php if(count($info->category ?? []) != 0): ?>
								<div class="product-tag"><p class="cat"><?php echo e(__('Category')); ?> : 
									<?php $__currentLoopData = $info->category ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a href="<?php echo e(url('/category',$row->slug)); ?>" class="categories" data-id="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></a>
									
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							       </p></div>
								<?php endif; ?>
								<?php if(count($info->category ?? []) != 0): ?>
								<div class="product-tag"><p class="cat"><?php echo e(__('Brand')); ?> : 
									<?php $__currentLoopData = $info->brands ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a href="<?php echo e(url('/brand',$row->slug)); ?>"><?php echo e($row->name); ?></a>
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							       </p></div>
								<?php endif; ?>
								<?php if(count($info->category ?? []) != 0): ?>
								<div class="product-tag"><p><?php echo e(__('Tags')); ?> : 
									<?php $__currentLoopData = $info->tags ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a href="<?php echo e(url('/tag',$row->slug)); ?>" class="text-dark"><?php echo e($row->name); ?></a>,
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							       </p></div>
								<?php endif; ?>
							</div>
						</div>


					</div>
				</div>
				
				<div class="product-info">
					<div class="row">
						<div class="col-lg-6 col-12">
							<ul class="nav nav-tabs" id="myTab" role="tablist">
								<li class="nav-item" role="presentation">
									<button class="nav-link active" id="description-tab" data-bs-toggle="tab" data-bs-target="#description" type="button" role="tab" aria-controls="description" aria-selected="true"><?php echo e(__('Description')); ?></button>
								</li>
								<li class="nav-item" role="presentation">
									<button class="nav-link" id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews" type="button" role="tab" aria-controls="reviews" aria-selected="false"><?php echo e(__('Reviews')); ?></button>
								</li>
							</ul>
							<div class="tab-content" id="myTabContent">
								<div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
									<div class="tab-single">
										<div class="row">
											<div class="col-12">
												<div class="single-des">
													<h4><?php echo e(__('Overview:')); ?></h4>
													<?php echo e(content_format($info->description->value ?? '')); ?>

												</div>
												
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
									<div class="tab-single reviews-panel">
										<div class="row">
											<div class="col-12">
												<div class="ratting-main">
													<div class="avg-ratting">
														<h4><?php echo e($info->rating); ?> <span>(Overall)</span></h4>
														<span>Based on <?php echo e($info->reviews_count); ?> Comments</span>
													</div>
													
												</div>
												<nav aria-label="navigation ">
													<ul class="pagination pagination-sm">
													</ul>
												</nav>
												
												<!-- Review -->
												
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="product-more">
								<div class="row">
									<div class="col-lg-8">
										<div class="section__title text-left p-0 mb-0">
											<span class="sub__title wow fadeInUp" data-wow-delay=".2s"><?php echo e($meta->product_page_short_title ?? __('Wanna more?')); ?></span>
											<h2 class="main__title s-title-single wow fadeInUp" data-wow-delay=".4s"><span></span><?php echo e($meta->product_page_title ?? __('Check Related products')); ?></h2>
										</div>
									</div>
								</div>
								<div class="row product-single-slider">
									
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Shop Single -->
		<input type="hidden" id="term_id" value="<?php echo e($info->id); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('theme/jquery.unveil.js')); ?>"></script>
<script src="<?php echo e(asset('theme/resto/js/product-details.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.resto.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/resto/details.blade.php ENDPATH**/ ?>