

<?php $__env->startSection('title','Edit Page'); ?>

<?php $__env->startSection('head'); ?>
<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>'Edit Page','prev'=> route('seller.page.index')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/summernote/summernote-bs4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.storenotification','data' => []]); ?>
<?php $component->withName('storenotification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="row">
  <div class="col-12">
    <div class="card">
        <div class="card-header">
          <h4><?php echo e(__('Edit Page')); ?></h4>
        </div>
        <form method="POST" action="<?php echo e(route('seller.page.update', $info->id)); ?>" enctype="multipart/form-data" class="ajaxform">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="card-body">
            <div class="form-group">
              <label><?php echo e(__('Page Title')); ?></label>
              <input type="text" class="form-control" placeholder="Page Title" required name="title" value="<?php echo e($info->title); ?>">
            </div>
            <?php if(!in_array($info->slug,['terms-and-conditions','privacy-policy','return-policy'])): ?>
            <div class="form-group">
              <label><?php echo e(__('Slug')); ?></label>
              <input type="text" class="form-control"  required name="slug" value="<?php echo e($info->slug); ?>">
            </div>
            <?php else: ?>
            <input type="hidden" name="slug" value="<?php echo e($info->slug); ?>">
            <?php endif; ?>
            <div class="form-group">
                <label><?php echo e(__('Short Description')); ?></label>
                <textarea name="page_excerpt" cols="30" rows="10" class="form-control"><?php echo e($meta->page_excerpt ?? ''); ?></textarea>
            </div>
            <div class="form-group">
              <label><?php echo e(__('Page Content')); ?></label>
              <textarea name="page_content" class="summernote form-control"><?php echo e($meta->page_content ?? ''); ?></textarea>
            </div>
            <div class="form-group">
              <div class="custom-file mb-3">
                <label><?php echo e(__('Status')); ?></label>
                <select name="status" class="form-control">
                  <option value="1" <?php echo e(($info->status == 1) ? 'selected' : ''); ?>><?php echo e(__('Active')); ?></option>
                  <option value="0" <?php echo e(($info->status == 0) ? 'selected' : ''); ?>><?php echo e(__('Inactive')); ?></option>
                </select>
              </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                  <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn"><?php echo e(__('Update')); ?></button>
                </div>
            </div>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script src="<?php echo e(asset('admin/assets/js/summernote-bs4.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/summernote.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/page/edit.blade.php ENDPATH**/ ?>