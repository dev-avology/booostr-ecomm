<?php $__currentLoopData = $info->optionwithcategories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="option-colors">	
	
	<h6><span class="text-danger <?php echo e($row->is_required == 1 ? 'required_var' : ''); ?>" data-id="<?php echo e($row->id); ?>"><?php echo e($row->is_required == 1 ? '*' : ''); ?></span><?php echo e($row->category->name ?? ''); ?> :</h6>

	<?php $__currentLoopData = $row->priceswithcategories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="single_color color">
	<?php if($row->category->slug == 'checkbox'): ?>
	&nbsp
	<input 

	class="custom-control variations<?php echo e($row->id); ?> pricesvariations <?php echo e($row->is_required == 1 ? 'req' : ''); ?>" 
	data-stockstatus="<?php echo e($price->stock_status); ?>"  
	data-stockmanage="<?php echo e($price->stock_manage); ?>" 
	data-sku="<?php echo e($price->sku); ?>" 
	data-qty="<?php echo e($price->qty); ?>"  
	data-oldprice="<?php echo e($price->old_price); ?>" 
	data-price="<?php echo e($price->price); ?>" 
	type="<?php echo e($row->select_type == 1 ? 'checkbox' : 'radio'); ?>" 
	id="variation<?php echo e($price->id.$k+$key); ?>" 
	name="option[<?php echo e($row->id); ?>][]" 
	value="<?php echo e($price->id ?? ''); ?>"
	<?php echo e($row->is_required == 1 && $k == 0 ? 'checked' : ''); ?>

	>

	<label for="variation<?php echo e($price->id.$k+$key); ?>"><?php echo e($price->category->name ?? ''); ?></label>
	<?php elseif($row->category->slug == 'checkbox_custom'): ?>
	&nbsp
	<div class="custom_checkbox variation<?php echo e($price->id ?? ''); ?>">
		<input 
		class="custom-control variations<?php echo e($row->id); ?> pricesvariations <?php echo e($price->is_required == 1 ? 'req' : ''); ?>" 
		data-stockstatus="<?php echo e($price->stock_status); ?>"  
		data-stockmanage="<?php echo e($price->stock_manage); ?>" 
		data-sku="<?php echo e($price->sku); ?>" 
		data-qty="<?php echo e($price->qty); ?>"  
		data-oldprice="<?php echo e($price->old_price); ?>" 
		data-price="<?php echo e($price->price); ?>" 
		type="<?php echo e($row->select_type == 1 ? 'checkbox' : 'radio'); ?>" 
		id="variation<?php echo e($price->id.$k+$key); ?>" 
		name="option[<?php echo e($row->id); ?>][]" 
		value="<?php echo e($price->id ?? ''); ?>">
		<label for="variation<?php echo e($price->id.$k+$key); ?>"><?php echo e($price->category->name ?? ''); ?></label>
	</div>
	<?php elseif($row->category->slug == 'radio'): ?>
	&nbsp

	<input 
	class="custom-control variations<?php echo e($row->id); ?> pricesvariations <?php echo e($row->is_required == 1 ? 'req' : ''); ?>" 
	data-stockstatus="<?php echo e($price->stock_status); ?>"  
	data-stockmanage="<?php echo e($price->stock_manage); ?>" 
	data-sku="<?php echo e($price->sku); ?>" 
	data-qty="<?php echo e($price->qty); ?>"  
	data-oldprice="<?php echo e($price->old_price); ?>" 
	data-price="<?php echo e($price->price); ?>" 
	type="<?php echo e($row->select_type == 1 ? 'checkbox' : 'radio'); ?>" 
	id="variation<?php echo e($price->id.$k+$key); ?>" 
	name="option[<?php echo e($row->id); ?>][]" 
	value="<?php echo e($price->id ?? ''); ?>">

	<label for="variation<?php echo e($price->id.$k+$key); ?>"><?php echo e($price->category->name ?? ''); ?></label>


	<?php elseif($row->category->slug == 'radio_custom'): ?>
	&nbsp
	<div class="custom_radio_section variations<?php echo e($row->id); ?> variation<?php echo e($price->id ?? ''); ?>">
		<input 
		class="custom-control pricesvariations <?php echo e($price->is_required == 1 ? 'req' : ''); ?>" 
		data-stockstatus="<?php echo e($price->stock_status); ?>"  
		data-stockmanage="<?php echo e($price->stock_manage); ?>" 
		data-sku="<?php echo e($price->sku); ?>" 
		data-qty="<?php echo e($price->qty); ?>"  
		data-oldprice="<?php echo e($price->old_price); ?>" 
		data-price="<?php echo e($price->price); ?>" 
		type="<?php echo e($row->select_type == 1 ? 'checkbox' : 'radio'); ?>" 
		id="variation<?php echo e($price->id.$k+$key); ?>" 
		name="option[<?php echo e($row->id); ?>][]" 
		value="<?php echo e($price->id ?? ''); ?>">
		<label for="variation<?php echo e($price->id.$k+$key); ?>"><?php echo e($price->category->name ?? ''); ?></label>
	</div>
	<?php elseif($row->category->slug == 'color_single'): ?>
	<div class="color_widget">
		<div class="single_color">
			<input class=" variations<?php echo e($row->id); ?> color_single pricesvariations <?php echo e($price->is_required == 1 ? 'req' : ''); ?>"  data-stockstatus="<?php echo e($price->stock_status); ?>"  
		data-stockmanage="<?php echo e($price->stock_manage); ?>" 
		data-sku="<?php echo e($price->sku); ?>" 
		data-qty="<?php echo e($price->qty); ?>"  
		data-oldprice="<?php echo e($price->old_price); ?>" 
		data-price="<?php echo e($price->price); ?>" 
		type="<?php echo e($row->select_type == 1 ? 'checkbox' : 'radio'); ?>" 
		id="variation<?php echo e($price->id.$k+$key); ?>" 
		name="option[<?php echo e($row->id); ?>][]" 
		value="<?php echo e($price->id ?? ''); ?>">

		<label class="one variation<?php echo e($price->id.$k+$key); ?> <?php if(strtolower($price->category->name ?? '') != 'white'): ?> text-light <?php else: ?> text-dark <?php endif; ?>" for="variation<?php echo e($price->id.$k+$key); ?>"  style="background-color: <?php echo e($price->category->name ?? ''); ?>"><i></i></label>
			
		</div>

	</div>
	<?php elseif($row->category->slug == 'color_multi'): ?>
	<div class="color_widget">
		<div class="single_color">
			<input class=" variations<?php echo e($row->id); ?> color_single pricesvariations <?php echo e($price->is_required == 1 ? 'req' : ''); ?>"  data-stockstatus="<?php echo e($price->stock_status); ?>"  
		data-stockmanage="<?php echo e($price->stock_manage); ?>" 
		data-sku="<?php echo e($price->sku); ?>" 
		data-qty="<?php echo e($price->qty); ?>"  
		data-oldprice="<?php echo e($price->old_price); ?>" 
		data-price="<?php echo e($price->price); ?>" 
		type="<?php echo e($row->select_type == 1 ? 'checkbox' : 'radio'); ?>" 
		id="variation<?php echo e($price->id.$k+$key); ?>" 
		name="option[<?php echo e($row->id); ?>][]" 
		value="<?php echo e($price->id ?? ''); ?>">

		<label class="one variation<?php echo e($price->id.$k+$key); ?> <?php if(strtolower($price->category->name ?? '') != 'white'): ?> text-light <?php else: ?> text-dark <?php endif; ?>" for="variation<?php echo e($price->id.$k+$key); ?>"  style="background-color: <?php echo e($price->category->name ?? ''); ?>"></label>
			
		</div>

	</div>
	<?php endif; ?>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/components/variations.blade.php ENDPATH**/ ?>