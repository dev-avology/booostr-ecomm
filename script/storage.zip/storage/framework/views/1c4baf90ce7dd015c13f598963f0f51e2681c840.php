<?php if(!empty($menus)): ?>
<?php
$mainMenus=$menus['data'] ?? [];

?>
<?php $__currentLoopData = $mainMenus ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

<?php if(isset($row->children)): ?>

<li>
	<a  href="javascript:void(0)" >
		<?php echo e($row->text); ?>  
		
	</a>
	<ul class="dropdown" >
		<?php $__currentLoopData = $row->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childrens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
		<?php echo $__env->make('theme.grshop.components.menu.child', ['childrens' => $childrens], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</li>

<?php else: ?>
<li >
	<a <?php if(url()->current() == url($row->href)): ?> class="active" <?php endif; ?> href="<?php echo e(url($row->href)); ?>" <?php if(!empty($row->target)): ?> target="<?php echo e($row->target); ?>" <?php endif; ?>><?php echo e($row->text); ?> 

	</a>
</li>
<?php endif; ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/grshop/components/menu/parent.blade.php ENDPATH**/ ?>