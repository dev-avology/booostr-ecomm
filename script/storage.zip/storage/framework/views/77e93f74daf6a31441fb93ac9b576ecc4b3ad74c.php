
<?php $__env->startSection('content'); ?>
<?php
$autoloaddata=getautoloadquery();
$currency_data=$autoloaddata['currency_data'];
?>
<!-- Start Breadcrumbs Area -->
		<div class="breadcrumbs" style="background-image:url(<?php echo e(asset($page_data->wishlist_page_banner ?? '')); ?>)">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-8 col-12">
						<div class="breadcrumbs-content">
							<h1 class="page-title"> <?php echo e($page_data->wishlist_page_title ?? 'Wishlist'); ?></h1>
							<p><?php echo e($page_data->wishlist_page_description ?? ''); ?></p>
						</div>
						<ul class="breadcrumb-nav">
							<li><a href="<?php echo e(url('/')); ?>"><i class="icofont-home"></i> Home</a></li>
							<li><i class="icofont-fast-food"></i> <?php echo e(__('Wishlist')); ?></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Breadcrumbs Area -->
		
		
		<!-- Shopping Cart -->
		<div class="shopping-cart section">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<!-- Shopping Summery -->
						<table class="table shopping-summery">
							<thead>
								<tr class="main-hading">
									<th><i class="icofont-price"></i> <?php echo e(__('PRODUCT')); ?></th>
									<th><i class="icofont-pencil-alt-5"></i> <?php echo e(__('NAME')); ?></th>
									<th class="text-center"><i class="icofont-money"></i> <?php echo e(__('UNIT PRICE')); ?></th>
									
									
									<th class="text-center"><i class="icofont-trash"></i><?php echo e(__('Remove')); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td class="image" data-title="No"><img src="<?php echo e(asset($row->options->preview)); ?>" alt="<?php echo e($row->name); ?>"></td>
									<td class="product-desc" data-title="Description">
										<p class="product-name"><a href="<?php echo e(url('/product',$row->options->slug)); ?>"><?php echo e($row->name); ?></a></p>
										
									</td>
									<td class="price" data-title="Price"><span><?php echo e(number_format($row->price,2)); ?> </span></td>
									
									
									<td class="action" data-title="Remove"><a href="<?php echo e(url('/remove-wishlist',$row->rowId)); ?>" class=""><i class="icofont-trash remove-icon"></i></a></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</tbody>
						</table>
						<!--/ End Shopping Summery -->
					</div>
				</div>
				
			</div>
		</div>
		<!--/ End Shopping Cart -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.resto.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/theme/resto/wishlist.blade.php ENDPATH**/ ?>