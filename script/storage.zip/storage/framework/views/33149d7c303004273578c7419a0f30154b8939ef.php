

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-sm-12">
    <div class="card card-primary">
      <div class="card-body">
      <div class="row">
        <div class="col-sm-3">
          <ul class="nav nav-pills flex-column" id="myTab4" role="tablist">
            <li class="nav-item">
              <a class="nav-link <?php echo e(route('seller.product.edit',$product_id) == url()->current() ? 'active' : ''); ?>" href="<?php echo e(route('seller.product.edit',$product_id)); ?>" ><?php echo e(__('General Information')); ?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(url('/seller/product/edit/'.$product_id.'/price') == url()->current() ? 'active' : ''); ?>"  href="<?php echo e(url('/seller/product/edit/'.$product_id.'/price')); ?>"><?php echo e(__('Price')); ?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(url('/seller/product/edit/'.$product_id.'/image') == url()->current() ? 'active' : ''); ?>"  href="<?php echo e(url('/seller/product/edit/'.$product_id.'/image')); ?>"><?php echo e(__('Images')); ?></a>
            </li>
            <!-- <li class="nav-item">
              <a class="nav-link <?php echo e(url('/seller/product/edit/'.$product_id.'/discount') == url()->current() ? 'active' : ''); ?>"  href="<?php echo e(url('/seller/product/edit/'.$product_id.'/discount')); ?>"><?php echo e(__('Discount')); ?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(url('/seller/product/edit/'.$product_id.'/seo') == url()->current() ? 'active' : ''); ?>"  href="<?php echo e(url('/seller/product/edit/'.$product_id.'/seo')); ?>"><?php echo e(__('SEO')); ?></a>
            </li>
            <li class="nav-item">
               <a class="nav-link <?php echo e(url('/seller/product/edit/'.$product_id.'/express-checkout') == url()->current() ? 'active' : ''); ?>"  href="<?php echo e(url('/seller/product/edit/'.$product_id.'/express-checkout')); ?>"><?php echo e(__('Express Checkout')); ?></a>
            <li class="nav-item">
               <a class="nav-link <?php echo e(url('/seller/product/edit/'.$product_id.'/barcode') == url()->current() ? 'active' : ''); ?>"  href="<?php echo e(url('/seller/product/edit/'.$product_id.'/barcode')); ?>"><?php echo e(__('Barcode Print')); ?> <?php if(tenant('barcode') != 'on'): ?>  <i class="fa fa-lock text-danger"></i> <?php endif; ?></a>   
            </li> -->
          </ul>
        </div>
        <div class="col-sm-9">
          <div class="tab-content no-padding">
            <?php echo $__env->yieldContent('product_content'); ?>
          </div>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>
<?php echo $__env->yieldContent('product_extra_content'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\avology\script\resources\views/seller/product/productmain.blade.php ENDPATH**/ ?>